using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace CybersecurityChatbot
{
    // ---------------------------------------------------------------
    // Model: one row from the tasks table
    // ---------------------------------------------------------------
    public class TaskItem
    {
        public int      Id          { get; set; }
        public string   Title       { get; set; }
        public string   Description { get; set; }
        public DateTime?Reminder    { get; set; }
        public bool     IsCompleted { get; set; }
        public DateTime CreatedAt   { get; set; }
    }

    // ---------------------------------------------------------------
    // Model: one row from the activity_log table
    // ---------------------------------------------------------------
    public class ActivityEntry
    {
        public int      Id          { get; set; }
        public string   Action      { get; set; }
        public string   Description { get; set; }
        public DateTime LoggedAt    { get; set; }
    }

    // ---------------------------------------------------------------
    // DatabaseHelper – wraps every SQL call the application needs.
    // The connection string is read from App.config at runtime.
    // ---------------------------------------------------------------
    public static class DatabaseHelper
    {
        // ------------------------------------------------------------------
        // Change these values to match YOUR MySQL server configuration,
        // or better yet keep them in App.config and read them from there.
        // ------------------------------------------------------------------
        private static readonly string _connectionString =
            "Server=localhost;Port=3306;Database=cybersecurity_chatbot;" +
            "User Id=root;Password=YOUR_PASSWORD_HERE;" +
            "SslMode=none;CharSet=utf8mb4;";

        // ------ helpers ---------------------------------------------------
        private static MySqlConnection GetConnection()
        {
            return new MySqlConnection(_connectionString);
        }

        public static bool TestConnection(out string error)
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    error = null;
                    return true;
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        // ==================================================================
        //  TASK CRUD
        // ==================================================================

        /// <summary>Returns every task ordered by creation date descending.</summary>
        public static List<TaskItem> GetAllTasks()
        {
            var list = new List<TaskItem>();
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "SELECT id, title, description, reminder, is_completed, created_at " +
                    "FROM tasks ORDER BY created_at DESC;", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new TaskItem
                        {
                            Id          = reader.GetInt32("id"),
                            Title       = reader.GetString("title"),
                            Description = reader.IsDBNull(reader.GetOrdinal("description"))
                                              ? string.Empty
                                              : reader.GetString("description"),
                            Reminder    = reader.IsDBNull(reader.GetOrdinal("reminder"))
                                              ? (DateTime?)null
                                              : reader.GetDateTime("reminder"),
                            IsCompleted = reader.GetBoolean("is_completed"),
                            CreatedAt   = reader.GetDateTime("created_at")
                        });
                    }
                }
            }
            return list;
        }

        /// <summary>Inserts a new task; returns the new auto-increment id.</summary>
        public static int AddTask(string title, string description, DateTime? reminder)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "INSERT INTO tasks (title, description, reminder) " +
                    "VALUES (@title, @desc, @reminder); " +
                    "SELECT LAST_INSERT_ID();", conn);

                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@desc",  string.IsNullOrWhiteSpace(description)
                                                          ? (object)DBNull.Value : description);
                cmd.Parameters.AddWithValue("@reminder", reminder.HasValue
                                                          ? (object)reminder.Value : DBNull.Value);

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        /// <summary>Marks a task as completed (is_completed = 1).</summary>
        public static void MarkTaskCompleted(int taskId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "UPDATE tasks SET is_completed = 1 WHERE id = @id;", conn);
                cmd.Parameters.AddWithValue("@id", taskId);
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>Permanently removes a task.</summary>
        public static void DeleteTask(int taskId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "DELETE FROM tasks WHERE id = @id;", conn);
                cmd.Parameters.AddWithValue("@id", taskId);
                cmd.ExecuteNonQuery();
            }
        }

        // ==================================================================
        //  ACTIVITY LOG
        // ==================================================================

        /// <summary>Appends one entry to the activity_log table.</summary>
        public static void LogActivity(string action, string description)
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    var cmd = new MySqlCommand(
                        "INSERT INTO activity_log (action, description) " +
                        "VALUES (@action, @desc);", conn);
                    cmd.Parameters.AddWithValue("@action", action);
                    cmd.Parameters.AddWithValue("@desc",   description ?? string.Empty);
                    cmd.ExecuteNonQuery();
                }
            }
            catch
            {
                // Logging should never crash the application.
            }
        }

        /// <summary>Returns the most recent <paramref name="limit"/> log entries.</summary>
        public static List<ActivityEntry> GetRecentLog(int limit = 10)
        {
            var list = new List<ActivityEntry>();
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "SELECT id, action, description, logged_at " +
                    "FROM activity_log ORDER BY logged_at DESC LIMIT @limit;", conn);
                cmd.Parameters.AddWithValue("@limit", limit);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new ActivityEntry
                        {
                            Id          = reader.GetInt32("id"),
                            Action      = reader.GetString("action"),
                            Description = reader.IsDBNull(reader.GetOrdinal("description"))
                                              ? string.Empty
                                              : reader.GetString("description"),
                            LoggedAt    = reader.GetDateTime("logged_at")
                        });
                    }
                }
            }
            return list;
        }

        // ==================================================================
        //  QUIZ RESULTS
        // ==================================================================

        public static void SaveQuizResult(int score, int total)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "INSERT INTO quiz_results (score, total) VALUES (@score, @total);", conn);
                cmd.Parameters.AddWithValue("@score", score);
                cmd.Parameters.AddWithValue("@total", total);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
