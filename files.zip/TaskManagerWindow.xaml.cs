using System;
using System.Windows;

namespace CybersecurityChatbot
{
    public partial class TaskManagerWindow : Window
    {
        public TaskManagerWindow()
        {
            InitializeComponent();
            LoadTasks();
        }

        // ------------------------------------------------------------------
        private void LoadTasks()
        {
            try
            {
                var tasks = DatabaseHelper.GetAllTasks();
                LvTasks.ItemsSource = null;
                LvTasks.ItemsSource = tasks;
                TxtStatus.Text = $"Loaded {tasks.Count} task(s).";
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"⚠️ Could not load tasks: {ex.Message}";
            }
        }

        // ------------------------------------------------------------------
        private void BtnAddTask_Click(object sender, RoutedEventArgs e)
        {
            string title = TxtTitle.Text.Trim();
            if (string.IsNullOrWhiteSpace(title))
            {
                MessageBox.Show("Please enter a task title.", "Validation",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string desc = TxtDescription.Text.Trim();
            DateTime? reminder = null;
            if (DpReminder.SelectedDate.HasValue)
                reminder = DpReminder.SelectedDate.Value;

            try
            {
                int newId = DatabaseHelper.AddTask(title, desc, reminder);
                string reminderText = reminder.HasValue
                    ? reminder.Value.ToString("MMM dd, yyyy")
                    : "no reminder";

                DatabaseHelper.LogActivity("TASK_ADDED",
                    $"Task #{newId} '{title}' added with {reminderText}.");

                TxtTitle.Text       = string.Empty;
                TxtDescription.Text = string.Empty;
                DpReminder.SelectedDate = null;

                LoadTasks();
                TxtStatus.Text = $"✅ Task '{title}' added successfully (ID #{newId}).";
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"⚠️ Error adding task: {ex.Message}";
            }
        }

        // ------------------------------------------------------------------
        private void BtnMarkComplete_Click(object sender, RoutedEventArgs e)
        {
            if (LvTasks.SelectedItem is TaskItem selected)
            {
                if (selected.IsCompleted)
                {
                    TxtStatus.Text = "Task is already marked as complete.";
                    return;
                }
                try
                {
                    DatabaseHelper.MarkTaskCompleted(selected.Id);
                    DatabaseHelper.LogActivity("TASK_COMPLETED",
                        $"Task #{selected.Id} '{selected.Title}' marked as completed.");
                    LoadTasks();
                    TxtStatus.Text = $"✅ Task '{selected.Title}' marked as complete.";
                }
                catch (Exception ex)
                {
                    TxtStatus.Text = $"⚠️ Error: {ex.Message}";
                }
            }
            else
            {
                TxtStatus.Text = "Please select a task first.";
            }
        }

        // ------------------------------------------------------------------
        private void BtnDeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (LvTasks.SelectedItem is TaskItem selected)
            {
                var result = MessageBox.Show(
                    $"Delete task '{selected.Title}'? This cannot be undone.",
                    "Confirm Delete",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        DatabaseHelper.DeleteTask(selected.Id);
                        DatabaseHelper.LogActivity("TASK_DELETED",
                            $"Task #{selected.Id} '{selected.Title}' deleted.");
                        LoadTasks();
                        TxtStatus.Text = $"🗑️ Task '{selected.Title}' deleted.";
                    }
                    catch (Exception ex)
                    {
                        TxtStatus.Text = $"⚠️ Error: {ex.Message}";
                    }
                }
            }
            else
            {
                TxtStatus.Text = "Please select a task to delete.";
            }
        }

        // ------------------------------------------------------------------
        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadTasks();
        }
    }
}
