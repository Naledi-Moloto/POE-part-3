using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CybersecurityChatbot
{
    // =========================================================================
    //  ActivityLogger  –  maintains an in-memory list of the last 50 actions
    //  and flushes each entry to the MySQL activity_log table.
    // =========================================================================
    public static class ActivityLogger
    {
        private static readonly List<(DateTime Timestamp, string Action, string Detail)>
            _log = new List<(DateTime, string, string)>();

        private const int MaxMemory = 50;

        // -----------------------------------------------------------------
        public static void Log(string action, string detail = "")
        {
            _log.Add((DateTime.Now, action, detail));
            if (_log.Count > MaxMemory)
                _log.RemoveAt(0);

            // Persist to MySQL (silently fail if DB is unavailable)
            DatabaseHelper.LogActivity(action, detail);
        }

        // -----------------------------------------------------------------
        /// <summary>Returns a formatted string of the last <paramref name="n"/> entries.</summary>
        public static string GetFormattedLog(int n = 10)
        {
            if (_log.Count == 0)
                return "📋 No activity has been recorded yet.";

            var recent = _log
                .AsEnumerable()
                .Reverse()
                .Take(n)
                .ToList();

            var sb = new StringBuilder();
            sb.AppendLine("📋 Recent Activity Log (latest first):");
            sb.AppendLine(new string('─', 48));

            foreach (var entry in recent)
            {
                sb.AppendLine($"🕐 {entry.Timestamp:HH:mm:ss}  [{entry.Action}]");
                if (!string.IsNullOrWhiteSpace(entry.Detail))
                    sb.AppendLine($"   {entry.Detail}");
            }

            return sb.ToString().TrimEnd();
        }

        // -----------------------------------------------------------------
        public static int Count => _log.Count;
    }

    // =========================================================================
    //  ResponseBank  –  randomised, thematic chatbot responses (Parts 1 & 2
    //  integration).  Keeps the chatbot feeling dynamic and varied.
    // =========================================================================
    public static class ResponseBank
    {
        private static readonly Random _rnd = new Random();

        // Pick one string at random from an array
        private static string Pick(params string[] options) =>
            options[_rnd.Next(options.Length)];

        // -----------------------------------------------------------------
        public static string Greeting() => Pick(
            "👋 Hello! I'm your Cybersecurity Assistant. How can I help you stay safe today?",
            "👋 Hey there! Ready to boost your cybersecurity? What can I do for you?",
            "👋 Hi! I'm here to help with all things cybersecurity. What's on your mind?",
            "👋 Greetings! Whether it's tips, tasks, or a quiz – I've got you covered. What do you need?"
        );

        public static string Farewell() => Pick(
            "👋 Stay safe online! Come back anytime.",
            "👋 Goodbye! Remember – think before you click!",
            "👋 Take care! Keep your passwords strong and your guard up.",
            "👋 See you later! Stay cyber-safe out there."
        );

        public static string Help() =>
            "🛡️ Here's what I can help you with:\n\n" +
            "📌 TASK MANAGER\n" +
            "  • 'add task'      – Add a cybersecurity task/reminder\n" +
            "  • 'view tasks'    – See all your tasks\n" +
            "  • 'complete task' – Mark a task as done\n" +
            "  • 'delete task'   – Remove a task\n\n" +
            "🎮 QUIZ\n" +
            "  • 'quiz'          – Start the cybersecurity mini-game\n\n" +
            "📋 ACTIVITY LOG\n" +
            "  • 'activity log'  – View recent bot actions\n\n" +
            "💡 TOPICS  (just mention any of these)\n" +
            "  phishing • passwords • malware • social engineering\n" +
            "  suspicious links • privacy • 2FA • public Wi-Fi • ransomware\n\n" +
            "Type naturally – I understand many ways of asking!";

        // --- topic responses ---
        public static string Phishing() => Pick(
            "🎣 Phishing attacks trick you into revealing sensitive info via fake emails or websites.\n" +
            "✅ Always verify the sender's address, hover over links before clicking, and go directly to official sites.",

            "🎣 Spot phishing by looking for: urgency, misspelled domains, unexpected attachments, and requests for personal data.\n" +
            "✅ When in doubt, contact the organisation directly through their official website.",

            "🎣 Spear-phishing targets specific individuals using personal details. Even tech-savvy people fall for it.\n" +
            "✅ Enable 2FA so that stolen credentials alone can't compromise your account."
        );

        public static string Password() => Pick(
            "🔑 A strong password is at least 12 characters, mixing uppercase, lowercase, numbers, and symbols.\n" +
            "✅ Use a reputable password manager so every account gets its own unique password.",

            "🔑 Avoid common passwords like 'password123' or your pet's name – attackers try these first.\n" +
            "✅ Passphrases (e.g. 'Purple!Monkey$Dishwasher') are long, memorable, and hard to crack.",

            "🔑 Never reuse passwords across sites. A single breach can expose ALL your accounts.\n" +
            "✅ Check if your email has been in a breach at haveibeenpwned.com."
        );

        public static string Malware() => Pick(
            "🦠 Malware includes viruses, trojans, ransomware, and spyware. It enters via email attachments, downloads, and malicious sites.\n" +
            "✅ Keep antivirus updated and never open unexpected email attachments.",

            "🦠 Signs of malware: slow device, unexpected pop-ups, unknown processes, files disappearing.\n" +
            "✅ Regular backups protect you from ransomware – back up to a location not connected to your device.",

            "🦠 Trojans disguise themselves as legitimate software. Always download apps from official sources.\n" +
            "✅ Keep your OS and all software patched – most malware exploits known, unpatched vulnerabilities."
        );

        public static string SocialEngineering() => Pick(
            "🎭 Social engineering manipulates people rather than systems. Attackers may impersonate IT staff, banks, or authority figures.\n" +
            "✅ Verify identities through a separate, known channel before sharing any information.",

            "🎭 Pretexting, baiting, and tailgating are all social engineering tactics.\n" +
            "✅ Be sceptical of unsolicited contact. Legitimate organisations won't ask for your password.",

            "🎭 Urgency and fear are classic social engineering triggers – 'Act now or your account will be locked!'\n" +
            "✅ Pause, think critically, and verify before you act."
        );

        public static string SuspiciousLink() => Pick(
            "🔗 Hover over links to preview the actual URL before clicking. Phishing links often mimic real domains.\n" +
            "✅ Use a URL scanner like VirusTotal or Google Safe Browsing to check suspicious links.",

            "🔗 Shortened URLs (bit.ly, tinyurl) can hide malicious destinations.\n" +
            "✅ Use a link expander to reveal the real URL before clicking.",

            "🔗 Look for misspelled domains: 'arnazon.com' vs 'amazon.com', 'paypa1.com' vs 'paypal.com'.\n" +
            "✅ When in doubt, navigate directly to the site instead of clicking the link."
        );

        public static string Privacy() => Pick(
            "🔒 Review your social media privacy settings regularly. Limit who can see your posts, location, and personal info.\n" +
            "✅ Never share your full date of birth, address, or phone number publicly.",

            "🔒 Data brokers collect and sell your personal information. You can opt out of many of them.\n" +
            "✅ Use private browsing and avoid logging into accounts on shared computers.",

            "🔒 Oversharing on social media gives attackers data to craft targeted attacks.\n" +
            "✅ Think before you post – once online, information is very hard to remove."
        );

        public static string TwoFactorAuth() => Pick(
            "🔐 Two-factor authentication (2FA) adds a second verification step – even if your password is stolen, attackers can't log in.\n" +
            "✅ Enable 2FA on email, banking, and social media first. Use an authenticator app over SMS where possible.",

            "🔐 Authentication apps (Google Authenticator, Authy) generate time-based codes and are safer than SMS 2FA.\n" +
            "✅ Hardware keys like YubiKey offer the highest protection and are phishing-resistant.",

            "🔐 2FA dramatically reduces account takeover risk. Studies show it blocks over 99% of automated attacks.\n" +
            "✅ Set up 2FA now – go to your account's Security Settings and look for 'Two-Factor Authentication'."
        );

        public static string PublicWifi() => Pick(
            "📡 Public Wi-Fi is unencrypted – attackers on the same network can intercept your traffic.\n" +
            "✅ Use a trusted VPN whenever you connect to public Wi-Fi to encrypt your connection.",

            "📡 Evil-twin attacks create a fake Wi-Fi hotspot with a legitimate-sounding name to intercept your data.\n" +
            "✅ Avoid accessing banking or sensitive accounts on public networks.",

            "📡 Disable auto-connect to open Wi-Fi networks in your device settings.\n" +
            "✅ Use your mobile data hotspot instead of public Wi-Fi for sensitive tasks."
        );

        public static string Ransomware() => Pick(
            "💀 Ransomware encrypts your files and demands payment for the decryption key.\n" +
            "✅ Regular offline backups are your best defence. If infected, restore from backup instead of paying.",

            "💀 Ransomware often spreads via phishing emails or unpatched software vulnerabilities.\n" +
            "✅ Keep all software updated, use antivirus, and avoid opening unexpected attachments.",

            "💀 Paying the ransom does NOT guarantee file recovery and funds criminal organisations.\n" +
            "✅ Report ransomware to local authorities and cybersecurity agencies (e.g. CISA, NCSC)."
        );

        public static string PositiveSentiment() => Pick(
            "😊 Glad you're feeling positive! Staying upbeat is great for staying vigilant online too.",
            "😊 Love the energy! Is there anything cybersecurity-related I can help you with?",
            "😊 Great to hear! Remember – a positive mindset and good security habits go hand in hand."
        );

        public static string NegativeSentiment() => Pick(
            "😟 It sounds like you might be feeling stressed. Cybersecurity can be overwhelming – I'm here to help. What's worrying you?",
            "😟 I'm sorry to hear that. If you've experienced a security incident, take a deep breath – we can work through it together.",
            "😟 Feeling anxious about online safety is understandable. Let me know what's concerning you and I'll do my best to help."
        );

        public static string TaskAdded(string title) => Pick(
            $"✅ Got it! I've added '{title}' to your task list. You can view it anytime by saying 'view tasks'.",
            $"✅ Task '{title}' has been added successfully! Say 'view tasks' to see all your security tasks.",
            $"✅ '{title}' is now on your cybersecurity to-do list. Stay on top of it – security tasks matter!"
        );

        public static string OpeningTaskManager() => Pick(
            "📋 Opening your Task Manager now. You can add, view, complete, or delete security tasks there.",
            "📋 Launching the Task Manager! Keep your cybersecurity goals organised.",
            "📋 Here comes the Task Manager – your personal security to-do list!"
        );

        public static string StartingQuiz() => Pick(
            "🎮 Let's test your cybersecurity knowledge! Get ready for the quiz...",
            "🎮 Game time! Answer carefully – your cyber-safety depends on it! Starting quiz...",
            "🎮 Ready to prove your cybersecurity expertise? The quiz is loading!"
        );

        public static string Unknown() => Pick(
            "🤔 I didn't quite catch that. Try saying 'help' to see what I can assist with.",
            "🤔 Hmm, I'm not sure what you mean. Type 'help' for a list of things I can do.",
            "🤔 Could you rephrase that? I understand topics like phishing, passwords, tasks, and quizzes.",
            "🤔 I didn't recognise that command. Try asking about a cybersecurity topic or say 'help'."
        );
    }
}
