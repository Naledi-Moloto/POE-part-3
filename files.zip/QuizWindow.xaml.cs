using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CybersecurityChatbot
{
    // -----------------------------------------------------------------------
    // Question model
    // -----------------------------------------------------------------------
    public class QuizQuestion
    {
        public string           QuestionText { get; set; }
        public List<string>     Options      { get; set; }   // 2 options = T/F, 4 = MC
        public int              CorrectIndex { get; set; }
        public string           Explanation  { get; set; }
        public string           Type         { get; set; }   // "MC" or "TF"
    }

    // -----------------------------------------------------------------------
    // Quiz window
    // -----------------------------------------------------------------------
    public partial class QuizWindow : Window
    {
        // --- 12 questions covering phishing, passwords, social engineering,
        //     suspicious links, malware, 2FA, privacy, and more ---
        private readonly List<QuizQuestion> _questions = new List<QuizQuestion>
        {
            // 1 – Phishing (MC)
            new QuizQuestion
            {
                Type         = "MC",
                QuestionText = "1. Which of the following is the BEST way to verify whether an email asking for your login credentials is legitimate?",
                Options      = new List<string>
                {
                    "A)  Click the link in the email and see if the website looks real.",
                    "B)  Reply to the email and ask if it is genuine.",
                    "C)  Navigate directly to the company's official website by typing the URL.",
                    "D)  Forward the email to a friend and ask their opinion."
                },
                CorrectIndex = 2,
                Explanation  = "Always navigate directly to a company's official website by typing the known URL instead of clicking email links. Phishing emails often use look-alike domains or redirect you to fake login pages."
            },
            // 2 – Password safety (TF)
            new QuizQuestion
            {
                Type         = "TF",
                QuestionText = "2. True or False: Using the same strong password across multiple websites is safe as long as the password is longer than 16 characters.",
                Options      = new List<string>
                {
                    "✅  True – a long password is always secure.",
                    "❌  False – reusing passwords across sites is dangerous."
                },
                CorrectIndex = 1,
                Explanation  = "Even a very long password becomes a liability when reused. If one site suffers a data breach, attackers use credential-stuffing attacks to try that password everywhere else."
            },
            // 3 – Social engineering (MC)
            new QuizQuestion
            {
                Type         = "MC",
                QuestionText = "3. An attacker calls you pretending to be IT support and asks for your password to 'fix a problem on your account'. This is an example of:",
                Options      = new List<string>
                {
                    "A)  Malware injection.",
                    "B)  Pretexting (a social engineering technique).",
                    "C)  SQL injection.",
                    "D)  Man-in-the-middle attack."
                },
                CorrectIndex = 1,
                Explanation  = "Pretexting is a social-engineering tactic where the attacker invents a scenario (pretext) to manipulate the victim into revealing information. Legitimate IT staff will NEVER ask for your password."
            },
            // 4 – Suspicious links (TF)
            new QuizQuestion
            {
                Type         = "TF",
                QuestionText = "4. True or False: A URL that begins with 'https://' is always safe to visit because it is encrypted.",
                Options      = new List<string>
                {
                    "✅  True – HTTPS guarantees the site is trustworthy.",
                    "❌  False – HTTPS only encrypts the connection, not the site's intent."
                },
                CorrectIndex = 1,
                Explanation  = "HTTPS encrypts data in transit but says nothing about whether the site is legitimate. Phishing sites regularly obtain SSL certificates and use HTTPS. Always check the full domain name carefully."
            },
            // 5 – Two-factor authentication (MC)
            new QuizQuestion
            {
                Type         = "MC",
                QuestionText = "5. Which form of two-factor authentication (2FA) is considered MOST secure against phishing attacks?",
                Options      = new List<string>
                {
                    "A)  SMS one-time passwords sent to your phone.",
                    "B)  Security questions (e.g. mother's maiden name).",
                    "C)  Hardware security keys (e.g. YubiKey / FIDO2).",
                    "D)  Email verification codes."
                },
                CorrectIndex = 2,
                Explanation  = "Hardware FIDO2 security keys are phishing-resistant because they cryptographically bind to the legitimate domain. SMS codes can be intercepted via SIM-swapping or SS7 attacks."
            },
            // 6 – Password managers (TF)
            new QuizQuestion
            {
                Type         = "TF",
                QuestionText = "6. True or False: Using a reputable password manager is safer than trying to memorise unique passwords for every account.",
                Options      = new List<string>
                {
                    "✅  True – password managers generate and store strong unique passwords.",
                    "❌  False – password managers are a single point of failure."
                },
                CorrectIndex = 0,
                Explanation  = "Password managers let you use long, unique, random passwords for every account, which is far better than memorable (and therefore weaker) passwords. Top managers use zero-knowledge encryption so even the provider cannot read your vault."
            },
            // 7 – Malware / downloads (MC)
            new QuizQuestion
            {
                Type         = "MC",
                QuestionText = "7. You receive an email with an attachment named 'Invoice_2024.pdf.exe'. What should you do?",
                Options      = new List<string>
                {
                    "A)  Open it – PDF files cannot contain viruses.",
                    "B)  Rename the file to remove '.exe' and then open it.",
                    "C)  Delete it immediately and report it as phishing.",
                    "D)  Move it to the desktop and scan it next week."
                },
                CorrectIndex = 2,
                Explanation  = "The file extension is '.exe' (executable), not '.pdf'. Attackers disguise malware with double extensions. Never open unexpected executables and report suspicious emails immediately."
            },
            // 8 – Social engineering / urgency (TF)
            new QuizQuestion
            {
                Type         = "TF",
                QuestionText = "8. True or False: A sense of urgency in an email (e.g. 'Act NOW or your account will be closed!') is a common social engineering tactic used by attackers.",
                Options      = new List<string>
                {
                    "✅  True – urgency is a classic manipulation technique.",
                    "❌  False – legitimate businesses often send urgent account alerts."
                },
                CorrectIndex = 0,
                Explanation  = "Creating panic or urgency is a hallmark of phishing and social engineering. Attackers want you to act before you think. Slow down, verify through official channels, and never let urgency override good judgment."
            },
            // 9 – Privacy settings (MC)
            new QuizQuestion
            {
                Type         = "MC",
                QuestionText = "9. Which piece of information is MOST dangerous to share publicly on social media from a social engineering perspective?",
                Options      = new List<string>
                {
                    "A)  Your favourite sports team.",
                    "B)  Your full date of birth combined with your home city.",
                    "C)  A photo of your pet.",
                    "D)  A book you recently read."
                },
                CorrectIndex = 1,
                Explanation  = "Full date of birth + home city is exactly what identity thieves and social engineers collect to impersonate you, guess security questions, or commit identity fraud."
            },
            // 10 – Public Wi-Fi (TF)
            new QuizQuestion
            {
                Type         = "TF",
                QuestionText = "10. True or False: It is safe to access your online banking on public Wi-Fi as long as the banking site uses HTTPS.",
                Options      = new List<string>
                {
                    "✅  True – HTTPS protects the session completely.",
                    "❌  False – public Wi-Fi carries additional risks even with HTTPS."
                },
                CorrectIndex = 1,
                Explanation  = "Public Wi-Fi can be monitored or spoofed (evil-twin attacks). Attackers can perform SSL stripping or intercept traffic at the network layer. Always use a trusted VPN on public networks for sensitive tasks."
            },
            // 11 – Software updates (MC)
            new QuizQuestion
            {
                Type         = "MC",
                QuestionText = "11. Why is it important to install security updates promptly?",
                Options      = new List<string>
                {
                    "A)  Updates add new features and make software look better.",
                    "B)  Updates patch known vulnerabilities that attackers actively exploit.",
                    "C)  Unpatched software runs faster.",
                    "D)  Updates are only important for operating systems, not apps."
                },
                CorrectIndex = 1,
                Explanation  = "Once a vulnerability is publicly disclosed, attackers race to exploit unpatched systems. Security patches close those doors. Delaying updates gives attackers an open window."
            },
            // 12 – Ransomware (TF)
            new QuizQuestion
            {
                Type         = "TF",
                QuestionText = "12. True or False: Paying the ransom in a ransomware attack guarantees that the attacker will restore access to your files.",
                Options      = new List<string>
                {
                    "✅  True – attackers always keep their word to get more victims.",
                    "❌  False – there is no guarantee; many victims pay and still lose data."
                },
                CorrectIndex = 1,
                Explanation  = "Paying a ransom funds criminal organisations and there is no guarantee of file recovery. The best defence is regular offline/offsite backups and avoiding the initial infection through good email and browsing habits."
            }
        };

        private int  _currentIndex  = 0;
        private int  _score         = 0;
        private bool _answered      = false;

        private readonly Button[] _answerButtons;

        // colour references
        private static readonly SolidColorBrush Green  = new SolidColorBrush(Color.FromRgb(0x00, 0xFF, 0x9C));
        private static readonly SolidColorBrush Red    = new SolidColorBrush(Color.FromRgb(0xFF, 0x4C, 0x4C));
        private static readonly SolidColorBrush Grey   = new SolidColorBrush(Color.FromRgb(0x1F, 0x29, 0x37));
        private static readonly SolidColorBrush White  = new SolidColorBrush(Colors.White);

        public QuizWindow()
        {
            InitializeComponent();
            _answerButtons = new[] { BtnA, BtnB, BtnC, BtnD };
            DatabaseHelper.LogActivity("QUIZ_STARTED", "User started the Cybersecurity Quiz.");
            ShowQuestion();
        }

        // ------------------------------------------------------------------
        private void ShowQuestion()
        {
            _answered       = false;
            FeedbackPanel.Visibility = Visibility.Collapsed;
            BtnNext.IsEnabled = false;

            var q = _questions[_currentIndex];

            // Progress
            TxtProgress.Text = $"Question {_currentIndex + 1} of {_questions.Count}";
            TxtScore.Text    = $"Score: {_score}";
            TxtQType.Text    = q.Type == "TF" ? "TRUE / FALSE" : "MULTIPLE CHOICE";
            TxtQuestion.Text = q.QuestionText;

            // Progress bar width
            double pct = (double)_currentIndex / _questions.Count;
            ProgressFill.Width = pct * (ActualWidth > 0 ? ActualWidth - 48 : 680);

            // Show/hide buttons
            for (int i = 0; i < _answerButtons.Length; i++)
            {
                if (i < q.Options.Count)
                {
                    _answerButtons[i].Content    = q.Options[i];
                    _answerButtons[i].Visibility = Visibility.Visible;
                    _answerButtons[i].IsEnabled  = true;
                    _answerButtons[i].Background = Grey;
                    _answerButtons[i].Foreground = White;
                    _answerButtons[i].BorderBrush = new SolidColorBrush(Color.FromRgb(0x37, 0x41, 0x51));
                }
                else
                {
                    _answerButtons[i].Visibility = Visibility.Collapsed;
                }
            }
        }

        // ------------------------------------------------------------------
        private void AnswerBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_answered) return;
            _answered = true;

            var btn      = (Button)sender;
            int chosen   = int.Parse(btn.Tag.ToString());
            var q        = _questions[_currentIndex];
            bool correct = (chosen == q.CorrectIndex);

            if (correct) _score++;

            // Colour the buttons
            for (int i = 0; i < _answerButtons.Length; i++)
            {
                if (_answerButtons[i].Visibility != Visibility.Visible) continue;
                _answerButtons[i].IsEnabled = false;

                if (i == q.CorrectIndex)
                {
                    _answerButtons[i].Background  = Green;
                    _answerButtons[i].Foreground  = new SolidColorBrush(Color.FromRgb(0x0D, 0x11, 0x17));
                    _answerButtons[i].BorderBrush = Green;
                }
                else if (i == chosen)
                {
                    _answerButtons[i].Background  = Red;
                    _answerButtons[i].Foreground  = White;
                    _answerButtons[i].BorderBrush = Red;
                }
            }

            // Feedback
            TxtFeedbackHeader.Text      = correct ? "✅ Correct!" : "❌ Incorrect";
            TxtFeedbackHeader.Foreground = correct ? Green : Red;
            TxtFeedbackExplanation.Text = q.Explanation;
            FeedbackPanel.Visibility    = Visibility.Visible;
            TxtScore.Text               = $"Score: {_score}";
            BtnNext.IsEnabled           = true;

            // Update button label if last question
            if (_currentIndex == _questions.Count - 1)
                BtnNext.Content = "See Results 🏆";
        }

        // ------------------------------------------------------------------
        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {
            _currentIndex++;
            if (_currentIndex < _questions.Count)
            {
                ShowQuestion();
            }
            else
            {
                ShowResults();
            }
        }

        // ------------------------------------------------------------------
        private void ShowResults()
        {
            double pct = (double)_score / _questions.Count * 100;
            string grade = pct >= 90 ? "🏆 Expert"
                         : pct >= 70 ? "👍 Proficient"
                         : pct >= 50 ? "📚 Learning"
                         : "⚠️ Needs Work";

            // Save to DB
            try { DatabaseHelper.SaveQuizResult(_score, _questions.Count); } catch { }
            DatabaseHelper.LogActivity("QUIZ_COMPLETED",
                $"Quiz finished. Score: {_score}/{_questions.Count} ({pct:0}%) – {grade}.");

            var msg = $"Quiz Complete!\n\n" +
                      $"Your Score: {_score} / {_questions.Count}\n" +
                      $"Percentage: {pct:0}%\n" +
                      $"Rating: {grade}\n\n" +
                      (pct < 70
                          ? "Keep learning! Review the topics on phishing, passwords, and social engineering."
                          : "Great job! Keep up your cybersecurity knowledge.");

            MessageBox.Show(msg, "🎮 Quiz Results", MessageBoxButton.OK, MessageBoxImage.Information);
            Close();
        }
    }
}
