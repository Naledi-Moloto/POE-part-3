using System;
using System.Collections.Generic;
using System.Linq;

namespace CybersecurityChatbot
{
    // =========================================================================
    //  NlpEngine  –  simulates NLP using dictionaries, keyword lists, and
    //  basic string manipulation.  Recognises user intent even when phrased
    //  differently, e.g. "add task", "create reminder", "set up a task" all
    //  resolve to Intent.AddTask.
    // =========================================================================
    public enum Intent
    {
        Unknown,
        Greeting,
        Farewell,
        Help,
        // Task intents
        AddTask,
        ViewTasks,
        DeleteTask,
        CompleteTask,
        // Quiz intent
        StartQuiz,
        // Log intent
        ViewLog,
        // Cybersecurity topic intents (from Parts 1 & 2)
        Phishing,
        Password,
        Malware,
        SocialEngineering,
        SuspiciousLink,
        Privacy,
        TwoFactorAuth,
        PublicWifi,
        Ransomware,
        // Sentiment
        PositiveSentiment,
        NegativeSentiment
    }

    public class NlpResult
    {
        public Intent  Intent     { get; set; }
        public string  Keyword    { get; set; }   // matched keyword
        public double  Confidence { get; set; }   // 0.0 – 1.0
        public string  Sentiment  { get; set; }   // "positive", "negative", "neutral"
    }

    public static class NlpEngine
    {
        // -----------------------------------------------------------------
        // Intent keyword map  –  each entry is a list of surface forms that
        // all map to the same intent.  Checked in order; first match wins.
        // -----------------------------------------------------------------
        private static readonly Dictionary<Intent, List<string>> _intentMap =
            new Dictionary<Intent, List<string>>
        {
            // ---- greetings / farewells ----
            { Intent.Greeting, new List<string> {
                "hello","hi","hey","howdy","good morning","good afternoon",
                "good evening","greetings","sup","what's up","whats up" } },

            { Intent.Farewell, new List<string> {
                "bye","goodbye","see you","take care","exit","quit","cya","later" } },

            { Intent.Help, new List<string> {
                "help","assist","what can you do","commands","menu","options",
                "guide","how do i","support" } },

            // ---- task intents ----
            { Intent.AddTask, new List<string> {
                "add task","create task","new task","add a task","create a task",
                "set reminder","add reminder","create reminder","set a reminder",
                "remind me","schedule task","make a task","add security task",
                "i want to add","i need to add","log task","record task" } },

            { Intent.ViewTasks, new List<string> {
                "view tasks","show tasks","list tasks","my tasks","see tasks",
                "display tasks","show reminders","view reminders","what tasks",
                "check tasks","all tasks","pending tasks","task list","open tasks" } },

            { Intent.DeleteTask, new List<string> {
                "delete task","remove task","cancel task","erase task",
                "get rid of task","drop task","delete reminder","remove reminder" } },

            { Intent.CompleteTask, new List<string> {
                "complete task","mark complete","finish task","done task",
                "mark as done","task done","completed","mark task done",
                "i finished","mark finished" } },

            // ---- quiz ----
            { Intent.StartQuiz, new List<string> {
                "quiz","mini game","minigame","start quiz","play quiz",
                "test my knowledge","take quiz","cybersecurity quiz","challenge me",
                "trivia","knowledge test","test knowledge","play game" } },

            // ---- activity log ----
            { Intent.ViewLog, new List<string> {
                "activity log","show log","view log","history","recent actions",
                "what have you done","bot history","action log","log","show history",
                "activity history","recent activity","chatbot log" } },

            // ---- cybersecurity topics (Parts 1 & 2 integration) ----
            { Intent.Phishing, new List<string> {
                "phishing","phish","fake email","suspicious email","email scam",
                "spear phishing","vishing","smishing","fraudulent email","email attack" } },

            { Intent.Password, new List<string> {
                "password","passphrase","credentials","login details","strong password",
                "weak password","password manager","password safety","change password",
                "password tips","secure password" } },

            { Intent.Malware, new List<string> {
                "malware","virus","trojan","spyware","adware","worm","rootkit",
                "keylogger","infected","malicious software","antivirus" } },

            { Intent.SocialEngineering, new List<string> {
                "social engineering","pretexting","baiting","tailgating","manipulation",
                "impersonation","pretend to be","fake identity","human hacking" } },

            { Intent.SuspiciousLink, new List<string> {
                "suspicious link","bad link","malicious link","suspicious url",
                "unsafe link","don't click","do not click","strange link",
                "weird link","unknown link" } },

            { Intent.Privacy, new List<string> {
                "privacy","private data","personal information","data protection",
                "gdpr","personal data","oversharing","privacy settings" } },

            { Intent.TwoFactorAuth, new List<string> {
                "two factor","2fa","multi factor","mfa","authenticator",
                "two-step","one time password","otp","verification code" } },

            { Intent.PublicWifi, new List<string> {
                "public wifi","public wi-fi","open wifi","coffee shop wifi",
                "unsecured network","free wifi","hotspot","vpn" } },

            { Intent.Ransomware, new List<string> {
                "ransomware","ransom","encrypted files","pay ransom","locked files",
                "crypto locker","file encryption attack" } }
        };

        // -----------------------------------------------------------------
        // Positive / negative sentiment word lists
        // -----------------------------------------------------------------
        private static readonly List<string> _positiveWords = new List<string>
        {
            "good","great","awesome","excellent","thanks","thank","appreciate",
            "helpful","nice","love","perfect","happy","wonderful","fantastic",
            "brilliant","amazing","cool","well done","superb","pleased"
        };

        private static readonly List<string> _negativeWords = new List<string>
        {
            "bad","terrible","awful","hate","worst","useless","stupid","confused",
            "scared","worried","anxious","angry","frustrated","annoyed","upset",
            "lost","hopeless","broken","difficult","hard","problem","issue","error"
        };

        // -----------------------------------------------------------------
        // Main entry point – analyse raw user input
        // -----------------------------------------------------------------
        public static NlpResult Analyse(string userInput)
        {
            if (string.IsNullOrWhiteSpace(userInput))
                return new NlpResult { Intent = Intent.Unknown, Confidence = 0 };

            string lower = userInput.ToLowerInvariant().Trim();

            // 1. Detect intent
            var (intent, keyword, confidence) = DetectIntent(lower);

            // 2. Detect sentiment
            string sentiment = DetectSentiment(lower);

            // Override with sentiment intents if confidence is low
            if (intent == Intent.Unknown || confidence < 0.4)
            {
                if (sentiment == "positive")  intent = Intent.PositiveSentiment;
                if (sentiment == "negative")  intent = Intent.NegativeSentiment;
            }

            return new NlpResult
            {
                Intent     = intent,
                Keyword    = keyword,
                Confidence = confidence,
                Sentiment  = sentiment
            };
        }

        // -----------------------------------------------------------------
        private static (Intent intent, string keyword, double confidence)
            DetectIntent(string lower)
        {
            // Strip punctuation for cleaner matching
            string clean = new string(lower
                .Where(c => !char.IsPunctuation(c) || c == '\'')
                .ToArray());

            foreach (var kvp in _intentMap)
            {
                foreach (string phrase in kvp.Value)
                {
                    if (clean.Contains(phrase))
                    {
                        // Confidence: longer phrase = more specific = higher confidence
                        double conf = Math.Min(0.5 + phrase.Split(' ').Length * 0.15, 1.0);
                        return (kvp.Key, phrase, conf);
                    }
                }
            }

            return (Intent.Unknown, string.Empty, 0.0);
        }

        // -----------------------------------------------------------------
        private static string DetectSentiment(string lower)
        {
            int pos = _positiveWords.Count(w => lower.Contains(w));
            int neg = _negativeWords.Count(w => lower.Contains(w));

            if (pos > neg) return "positive";
            if (neg > pos) return "negative";
            return "neutral";
        }

        // -----------------------------------------------------------------
        // Helper – extract a task title heuristically from raw user input
        // e.g. "add task update firewall" → "update firewall"
        // -----------------------------------------------------------------
        public static string ExtractTaskTitle(string userInput)
        {
            string lower = userInput.ToLowerInvariant();
            string[] stripPhrases =
            {
                "add task","create task","new task","add a task","create a task",
                "set reminder","add reminder","create reminder","remind me to",
                "remind me","schedule task","log task","i want to add","i need to add"
            };

            foreach (var phrase in stripPhrases)
            {
                int idx = lower.IndexOf(phrase, StringComparison.OrdinalIgnoreCase);
                if (idx >= 0)
                {
                    string remainder = userInput.Substring(idx + phrase.Length).Trim();
                    if (remainder.Length > 2) return Capitalise(remainder);
                }
            }

            // Fallback – return original with punctuation stripped
            return Capitalise(userInput.Trim('?', '!', '.', ','));
        }

        private static string Capitalise(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            return char.ToUpper(s[0]) + s.Substring(1);
        }
    }
}
