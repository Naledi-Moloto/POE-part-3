-- ============================================================
-- Cybersecurity Chatbot - MySQL Database Setup Script
-- Run this entire script in MySQL Workbench or your MySQL client
-- ============================================================

-- 1. Create the database
CREATE DATABASE IF NOT EXISTS cybersecurity_chatbot
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE cybersecurity_chatbot;

-- 2. Tasks table
CREATE TABLE IF NOT EXISTS tasks (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(200)  NOT NULL,
    description TEXT,
    reminder    DATETIME,
    is_completed TINYINT(1)   NOT NULL DEFAULT 0,
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Activity log table  
CREATE TABLE IF NOT EXISTS activity_log (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    action      VARCHAR(100)  NOT NULL,
    description TEXT,
    logged_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Quiz results table (optional persistence)
CREATE TABLE IF NOT EXISTS quiz_results (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    score       INT           NOT NULL,
    total       INT           NOT NULL,
    played_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 5. Seed a couple of sample tasks so the view is never empty on first run
INSERT INTO tasks (title, description, reminder) VALUES
('Enable Two-Factor Authentication',
 'Set up 2FA on all critical accounts (email, banking, social media).',
 DATE_ADD(NOW(), INTERVAL 1 DAY)),
('Review Account Privacy Settings',
 'Check privacy settings on social media and cloud services.',
 DATE_ADD(NOW(), INTERVAL 3 DAY));

-- ============================================================
-- Connection details you will need in App.config / appsettings:
--   Server    : localhost
--   Port      : 3306  (default)
--   Database  : cybersecurity_chatbot
--   User      : root   (or a dedicated user you create below)
--   Password  : <your MySQL root password>
--
-- Optional: create a dedicated application user
-- CREATE USER 'chatbot_user'@'localhost' IDENTIFIED BY 'StrongPass123!';
-- GRANT ALL PRIVILEGES ON cybersecurity_chatbot.* TO 'chatbot_user'@'localhost';
-- FLUSH PRIVILEGES;
-- ============================================================
