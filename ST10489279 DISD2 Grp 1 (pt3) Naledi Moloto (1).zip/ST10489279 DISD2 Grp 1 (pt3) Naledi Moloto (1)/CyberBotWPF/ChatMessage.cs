// =======================================================================
// ChatMessage.cs  -  Models/
// -----------------------------------------------------------------------
// Represents a single message in the chat window.
// IsBot determines which side of the chat it appears on and what
// colour bubble it uses.
// =======================================================================

namespace CyberBotWPF.Models
{
    public class ChatMessage
    {
        // The text content of the message
        public string Text { get; set; } = "";

        // True  = message came from the bot  (left side, cyan bubble)
        // False = message came from the user (right side, dark bubble)
        public bool IsBot { get; set; }

        // Timestamp shown under each bubble
        public string Timestamp { get; set; } = DateTime.Now.ToString("HH:mm");

        // Optional: the sender label shown above the bubble
        public string SenderLabel => IsBot ? "Goose" : "You";
    }
}
