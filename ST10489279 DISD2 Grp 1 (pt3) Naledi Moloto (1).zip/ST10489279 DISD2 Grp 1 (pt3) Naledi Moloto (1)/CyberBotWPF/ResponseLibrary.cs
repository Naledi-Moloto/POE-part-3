// =======================================================================
// ResponseLibrary.cs  -  Bot/
// -----------------------------------------------------------------------
// Stores ALL predefined responses as Lists of strings.
// Each topic has multiple responses per sub-topic so the bot can
// randomly select one each time — creating variation in replies.
//
// The Random instance is shared so the same response is not picked
// twice in a row (LastIndex tracking is done in ConversationContext).
// =======================================================================

namespace CyberBotWPF.Bot
{
    public static class ResponseLibrary
    {
        private static readonly Random _rng = new Random();

        // ---------------------------------------------------------------
        // GET RANDOM
        // Returns a random item from a list, avoiding the last index
        // shown so the same response is not repeated immediately.
        // ---------------------------------------------------------------
        public static string GetRandom(List<string> list, ref int lastIndex)
        {
            if (list.Count == 1) return list[0];

            int index;
            do { index = _rng.Next(list.Count); }
            while (index == lastIndex);

            lastIndex = index;
            return list[index];
        }

        // ===============================================================
        // GREETINGS
        // ===============================================================
        public static readonly List<string> Greetings = new()
        {
            "Hello! Great to see you. I'm Goose — your personal cybersecurity guide. Type 'help' to see what I can teach you!",
            "Hey there! Welcome to Goose. I'm here to help you stay safe online. What would you like to learn today?",
            "Hi! I'm Goose, your cybersecurity awareness assistant. Ask me about phishing, passwords, malware, suspicious links, or social engineering!",
            "Greetings! I'm Goose. Ready to help you navigate the world of cybersecurity. What's on your mind?",
            "Hello and welcome! I'm here to help you stay safe in the digital world. Type 'help' to see all the topics I cover."
        };

        public static readonly List<string> HowAreYou = new()
        {
            "I'm doing great, thanks for asking! Always alert and ready to help. How about you — ready to learn something about cybersecurity today?",
            "Running at full capacity and ready to help! How are you doing? Is there a cybersecurity topic you'd like to explore?",
            "Fantastic, thank you! I never sleep, so I'm always here when you need me. What can I help you with today?"
        };

        public static readonly List<string> Purpose = new()
        {
            "My purpose is to teach you about cybersecurity threats and how to protect yourself from them in everyday life. I simulate real scenarios like phishing emails and suspicious links so you can practise spotting dangers safely. Type 'help' to see all my topics!",
            "I'm a Cybersecurity Awareness Assistant. I help users like you understand common cyber threats — phishing, malware, weak passwords, suspicious links, and social engineering — through interactive conversation and real-world examples.",
            "Think of me as your personal cybersecurity trainer. I explain threats, give you practical tips, and walk you through real-life scenarios so you know exactly what to do when danger appears online."
        };

        // ===============================================================
        // PHISHING — Multiple responses per sub-topic
        // ===============================================================
        public static readonly List<string> PhishingDefinitions = new()
        {
            "Phishing is a cyber attack where criminals send fake emails or messages impersonating trusted organisations — like your bank or employer — to steal your passwords, card numbers, or personal information.",
            "Phishing is when attackers 'fish' for victims by casting fake emails as bait. They pretend to be someone you trust to trick you into clicking a malicious link or handing over sensitive information.",
            "Phishing is a type of social engineering attack delivered via email or message. The attacker creates a convincing fake identity — like a bank or a tech company — to manipulate you into revealing your credentials."
        };

        public static readonly List<string> PhishingRedFlags = new()
        {
            "🚩 Red flag: Urgent language like 'Your account will be CLOSED in 24 hours!' is a classic phishing tactic designed to panic you into acting without thinking.",
            "🚩 Red flag: Check the sender's email address carefully. 'support@paypa1.com' looks like PayPal but the '1' instead of 'l' is a dead giveaway of a fake.",
            "🚩 Red flag: Generic greetings like 'Dear Customer' instead of your real name suggest the sender doesn't actually know who you are — a major phishing signal.",
            "🚩 Red flag: Unexpected attachments in emails are dangerous. Even if the sender looks familiar, you should never open a file you weren't expecting.",
            "🚩 Red flag: Shortened URLs like 'bit.ly/xyz' hide the real destination. Hover over any link before clicking to see where it actually leads.",
            "🚩 Red flag: Spelling mistakes and poor grammar throughout an email are common in phishing messages, especially those originating from overseas attackers."
        };

        public static readonly List<string> PhishingTips = new()
        {
            "✅ Tip: Always hover over a link before clicking it. Your browser will show the real URL at the bottom of the screen — if it looks suspicious, don't click.",
            "✅ Tip: When in doubt, go directly to the website by typing the address manually in your browser. Never use the link provided in the email.",
            "✅ Tip: Enable spam filters on your email account. Most modern email providers can automatically detect and quarantine phishing attempts.",
            "✅ Tip: Never give out your password, PIN, or card number via email. No legitimate organisation will ever ask for these through an email.",
            "✅ Tip: Report suspicious emails to your IT team or mark them as spam. This helps train your email provider's filter to catch similar attacks.",
            "✅ Tip: Check the sender's full email address — not just the display name. A name can say 'PayPal Support' while the actual address is completely different."
        };

        public static readonly List<string> PhishingScenarios = new()
        {
            "📧 SCENARIO: You receive an email from 'security@nettbank-alerts.com' saying your account is compromised and you must click a link immediately. VERDICT: Phishing! The domain 'nettbank-alerts.com' is fake, urgency is used to panic you, and the link is shortened to hide its destination.",
            "📧 SCENARIO: An email from 'hr@yourcompany-payroll.net' asks you to confirm your bank details for this month's salary. VERDICT: Phishing! Your real HR team would never ask for bank details via email, and the domain is slightly different from your actual company's.",
            "📧 SCENARIO: You get a message from 'support@micros0ft.com' saying your Windows licence has expired and you must pay now. VERDICT: Phishing! Notice the '0' instead of 'o' in Microsoft. Legitimate companies don't demand payment via email links."
        };

        // ===============================================================
        // PASSWORDS — Multiple responses per sub-topic
        // ===============================================================
        public static readonly List<string> PasswordDefinitions = new()
        {
            "A strong password is one that is very difficult for an attacker or automated tool to guess or crack. It should be at least 12 characters long, mix uppercase and lowercase letters, include numbers and symbols, and NOT be based on personal information.",
            "A strong password is long, random, and unique. Length matters most — a 16-character password is exponentially harder to crack than an 8-character one, even if both use the same character types.",
            "A strong password has four properties: length (12+ characters), complexity (mix of letters, numbers, symbols), uniqueness (not reused across sites), and unpredictability (not based on your name, birthday, or dictionary words)."
        };

        public static readonly List<string> PasswordTips = new()
        {
            "✅ Tip: Use at least 12 characters — the longer your password, the more combinations an attacker must try to crack it. 16+ characters is ideal.",
            "✅ Tip: Use a different password for every single account. If one account is breached, attackers won't be able to use the same password on your other accounts.",
            "✅ Tip: Use a password manager like Bitwarden (free) or 1Password to store all your passwords securely. You only need to remember one master password.",
            "✅ Tip: Enable Two-Factor Authentication (2FA) on every account that supports it. Even if your password is stolen, 2FA blocks attackers from logging in.",
            "✅ Tip: Change your password immediately if you suspect your account has been breached. Check haveibeenpwned.com to see if your email appears in known data breaches.",
            "✅ Tip: Mix uppercase, lowercase, numbers, and symbols. For example: P@ssw0rd#99! is far stronger than simply 'password'."
        };

        public static readonly List<string> PasswordsToAvoid = new()
        {
            "❌ Avoid: 'password123' — this is literally the most common password in the world and the first thing any attacker tries.",
            "❌ Avoid: Using your name, birthday, or pet's name. Attackers research their targets on social media before trying passwords.",
            "❌ Avoid: Keyboard patterns like 'qwerty', 'asdfgh', or '123456'. These are on every hacker's password list.",
            "❌ Avoid: Reusing the same password across multiple websites. One breach exposes ALL your accounts if you reuse passwords.",
            "❌ Avoid: Short passwords under 8 characters. Modern computers can crack an 8-character password in minutes using brute force."
        };

        public static readonly List<string> PassphraseInfo = new()
        {
            "💡 A passphrase is 4+ random words joined together — like 'Coffee-Lamp-Rocket-47!'. It's easy for you to remember but almost impossible for a computer to crack because of its length.",
            "💡 Passphrases work because length beats complexity. 'correct-horse-battery-staple' is longer and stronger than 'P@55w0rd' even though it's just words.",
            "💡 To create a strong passphrase: pick 4 completely random words, join them with symbols or hyphens, and add a number. Example: 'Purple$Cloud_Fence_92'. Easy to type, nearly impossible to crack."
        };

        // ===============================================================
        // SUSPICIOUS LINKS — Multiple responses per sub-topic
        // ===============================================================
        public static readonly List<string> LinksDefinitions = new()
        {
            "A suspicious link is any URL that may lead you to a harmful website. Malicious links can install malware on your device, redirect you to a fake login page, or trick you into downloading dangerous files.",
            "A malicious link is a web address designed to harm you. It might look identical to a real website but lead to a fake one controlled by attackers to steal your login details or infect your device.",
            "Suspicious links are URLs that contain warning signs suggesting they're not what they claim to be. They appear in emails, texts, social media messages, and even pop-up ads."
        };

        public static readonly List<string> LinksRedFlags = new()
        {
            "🚩 Red flag: Misspelled domain names like 'amaz0n.com' or 'g00gle.com' — attackers replace letters with numbers to create convincing fakes.",
            "🚩 Red flag: Fake subdomains like 'paypal.com.login.secure-net.com'. The real domain here is 'secure-net.com', not PayPal — the 'paypal.com' part is just the subdomain.",
            "🚩 Red flag: URL shorteners like 'bit.ly/abc123'. These hide the real destination. Always expand shortened URLs using a site like checkshorturl.com before clicking.",
            "🚩 Red flag: HTTP instead of HTTPS. Any site asking for your login or payment details should use HTTPS (the padlock icon). If it's just HTTP, don't enter any information.",
            "🚩 Red flag: Links ending in unexpected file extensions like '.exe', '.zip', or '.bat' — clicking these could download malware directly to your device.",
            "🚩 Red flag: Random strings of characters in the URL like 'xk29p.ru/login' with no recognisable brand name — a strong sign of a malicious site."
        };

        public static readonly List<string> LinksTips = new()
        {
            "✅ Tip: Hover over any link before clicking. Your browser shows the real destination URL in the bottom status bar — check it before you commit to clicking.",
            "✅ Tip: Use VirusTotal (virustotal.com) to scan any suspicious URL for free. Paste the link and it checks it against dozens of security databases instantly.",
            "✅ Tip: Type website addresses manually into your browser instead of clicking links from emails or messages. This guarantees you land on the real site.",
            "✅ Tip: If a link in an email makes you suspicious — don't click it. Go directly to the company's official website and log in from there instead.",
            "✅ Tip: Use a browser extension like uBlock Origin or Malwarebytes Browser Guard to automatically block known malicious URLs before they even load."
        };

        public static readonly List<string> LinksExercises = new()
        {
            "🔍 SPOT THE FAKE: Which is real?\nA) https://www.paypal.com/signin ✅ REAL\nB) https://paypal.com.secure-login.net ❌ FAKE — 'secure-login.net' is the real domain\nC) http://paypa1.com ❌ FAKE — 'l' replaced with '1', no HTTPS",
            "🔍 SPOT THE FAKE: Which is the real Netflix?\nA) https://www.netflix.com/login ✅ REAL\nB) https://netflix-account-verify.com ❌ FAKE — Netflix's domain is netflix.com only\nC) http://netf1ix.com ❌ FAKE — '1' replacing 'l', and no HTTPS",
            "🔍 SPOT THE FAKE: Which is the real bank link?\nA) https://www.fnb.co.za/login ✅ REAL\nB) https://fnb.co.za.secure-banking.com ❌ FAKE — fake subdomain trick\nC) https://www.fnb-secure-login.net ❌ FAKE — not the official fnb.co.za domain"
        };

        // ===============================================================
        // MALWARE — Multiple responses per sub-topic
        // ===============================================================
        public static readonly List<string> MalwareDefinitions = new()
        {
            "Malware is short for 'malicious software' — any program specifically designed to harm, disrupt, or gain unauthorised access to a device, network, or data without your knowledge or consent.",
            "Malware is an umbrella term covering any software with harmful intent. It can steal your data, spy on your activity, lock your files for ransom, or secretly use your computer to attack others.",
            "Malware is malicious code that attackers install on your device — often without you knowing. It can arrive via infected email attachments, compromised websites, fake software downloads, or infected USB drives."
        };

        public static readonly List<string> MalwareTypes = new()
        {
            "🦠 Virus: Attaches itself to legitimate files and spreads when you open them. Like a biological virus, it replicates and can corrupt or delete your data over time.",
            "🔒 Ransomware: Encrypts all your files and demands a ransom payment (usually in cryptocurrency) to unlock them. Even paying doesn't guarantee you get your files back.",
            "🕵️ Spyware: Runs silently in the background, recording your keystrokes, screenshots, and browsing history. Everything you type — including passwords — is sent to the attacker.",
            "🐴 Trojan: Disguises itself as a legitimate, useful application. Once installed, it opens a back door for attackers to access your device remotely.",
            "🐛 Worm: Spreads automatically across networks without any user action. A single infected device can spread a worm to every other device on the same network.",
            "📢 Adware: Floods your screen with unwanted advertisements and tracks your browsing habits. While less dangerous, it can slow your device and compromise your privacy."
        };

        public static readonly List<string> MalwareTips = new()
        {
            "✅ Tip: Keep your operating system and all apps updated. Software updates contain security patches that fix vulnerabilities attackers exploit to install malware.",
            "✅ Tip: Only download software from official, verified sources — the developer's own website, the Microsoft Store, or the App Store. Avoid pirated software.",
            "✅ Tip: Install a reputable antivirus program (Windows Defender is free and built in) and ensure its virus definitions are kept up to date.",
            "✅ Tip: Never open email attachments you were not expecting — even from people you know. Their account may have been compromised and used to spread malware.",
            "✅ Tip: Do not plug in USB drives you find or receive unexpectedly. 'Baiting' attacks leave infected USBs in public places hoping someone will plug them in out of curiosity.",
            "✅ Tip: Back up your important files regularly using the 3-2-1 rule: 3 copies, on 2 different media types, with 1 stored offsite (e.g. cloud storage)."
        };

        public static readonly List<string> BackupRuleInfo = new()
        {
            "💾 The 3-2-1 Backup Rule: Keep 3 total copies of your data, stored on 2 different media types (e.g. external HDD + cloud), with 1 copy stored offsite. This ensures you can recover even if ransomware strikes.",
            "💾 Backup tip: Even using a free cloud service like Google Drive or OneDrive for important documents is a great first step. If ransomware hits, you can restore from the cloud.",
            "💾 Backup tip: Test your backups regularly! Many people set up backups but never verify they can actually restore from them. A backup you can't restore from is worthless."
        };

        // ===============================================================
        // SOCIAL ENGINEERING — Multiple responses per sub-topic
        // ===============================================================
        public static readonly List<string> SocialDefinitions = new()
        {
            "Social engineering is the psychological manipulation of people into performing actions or revealing confidential information. Unlike hacking, it targets human behaviour rather than computer systems.",
            "Social engineering exploits human psychology — trust, authority, fear, and urgency — to trick people into handing over sensitive information or performing actions that compromise security.",
            "Social engineering is often more effective than technical hacking because it bypasses all technical security measures by targeting the one thing no firewall can protect: people."
        };

        public static readonly List<string> SocialTactics = new()
        {
            "🎭 Pretexting: The attacker invents a believable fake scenario — 'Hi, I'm from IT support and need your password to fix a critical issue.' They're not from IT. Never give your password to anyone.",
            "🎣 Baiting: Infected USB drives are deliberately left in public places like car parks or reception areas. Curious people pick them up and plug them in — instantly infecting their device.",
            "🚶 Tailgating: An attacker follows an authorised employee through a secure door by walking close behind them. They may pretend to be carrying heavy boxes so you hold the door open.",
            "📞 Vishing: Voice phishing — a scam phone call where someone pretends to be your bank, SARS, or Microsoft. They create urgency to get you to reveal personal information or make a payment.",
            "🤝 Quid Pro Quo: The attacker offers something (IT help, a prize, a service) in exchange for your login credentials or personal information.",
            "💼 Impersonation: Attackers dress as delivery drivers, contractors, or IT staff to gain physical access to buildings or devices. Always verify identities with official channels."
        };

        public static readonly List<string> SocialTips = new()
        {
            "✅ Tip: Always verify the identity of anyone requesting sensitive information. Call them back using the official number from the company's website — not the number they gave you.",
            "✅ Tip: Be suspicious whenever someone creates strong urgency or pressure. Urgency is the attacker's biggest tool — it stops you from thinking rationally.",
            "✅ Tip: Your employer, bank, or any legitimate organisation will NEVER ask for your password over the phone, via email, or in person. It's simply not how security works.",
            "✅ Tip: Do not plug in USB drives you found or received unexpectedly. Baiting attacks are extremely common and devastatingly effective.",
            "✅ Tip: Question all requests for access or sensitive information — even if the person seems legitimate or claims to be in authority. It's always okay to verify first.",
            "✅ Tip: Report suspected social engineering attempts to your security team immediately. The attacker may be targeting others in your organisation too."
        };

        // ===============================================================
        // HELP MENU TEXT
        // ===============================================================
        public static readonly string HelpText =
            "Here are the topics I can help you with:\n\n" +
            "🎣  phishing         — spot and avoid email scams\n" +
            "🔐  password         — create strong, secure passwords\n" +
            "🔗  links            — identify dangerous URLs\n" +
            "🦠  malware          — understand and prevent infections\n" +
            "🎭  social           — recognise manipulation tactics\n\n" +
            "You can also ask things like:\n" +
            "  • 'What is phishing?'\n" +
            "  • 'Give me a phishing tip'\n" +
            "  • 'Show me a phishing example'\n" +
            "  • 'Give me another tip'\n" +
            "  • 'What do you remember about me?'\n\n" +
            "Type 'quit' or close the window to exit.";

        // ===============================================================
        // FOLLOW-UP TRANSITIONS
        // Used as intro lines when the user asks for more on a topic
        // ===============================================================
        public static readonly List<string> FollowUpTransitions = new()
        {
            "Sure! Here's another one:",
            "Of course! Here's more on that:",
            "Absolutely — here's something else you should know:",
            "Great follow-up! Here's another important point:",
            "Happy to continue! Here's another:"
        };

        public static string GetRandomTransition()
        {
            return FollowUpTransitions[_rng.Next(FollowUpTransitions.Count)];
        }
    }
}
