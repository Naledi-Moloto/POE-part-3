// =======================================================================
// MainWindow.xaml.cs
// -----------------------------------------------------------------------
// Code-behind for the main chat window.
// Handles: message sending, bot responses, ASCII art loading,
//          memory display, sentiment display, typing animation,
//          WAV greeting, topic button clicks, and auto-scroll.
// =======================================================================

using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using CyberBotWPF.Bot;
using CyberBotWPF.Models;

namespace CyberBotWPF
{
    public partial class MainWindow : Window
    {
        // ---------------------------------------------------------------
        // FIELDS
        // ---------------------------------------------------------------
        private readonly ChatEngine _engine = new ChatEngine();

        // ObservableCollection automatically updates the UI when items are added
        private readonly ObservableCollection<ChatMessage> _messages = new();

        // Timer used to simulate the bot "typing" before showing a response
        private readonly DispatcherTimer _typingTimer = new();
        private string _pendingResponse = "";

        // ---------------------------------------------------------------
        // CONSTRUCTOR
        // ---------------------------------------------------------------
        public MainWindow()
        {
            InitializeComponent();

            // Bind the message list to the ItemsControl in XAML
            ChatList.ItemsSource = _messages;

            // Set up the typing timer (fires once after 800ms delay)
            _typingTimer.Interval = TimeSpan.FromMilliseconds(800);
            _typingTimer.Tick    += TypingTimer_Tick;

            // Load ASCII art into the sidebar
            LoadAsciiArt();

            // Play the WAV greeting
            AudioPlayer.PlayGreetingAsync();

            // Show the welcome message
            AddBotMessage(
                "Hello! I'm Goose — your Cybersecurity Awareness Assistant. 🛡️\n\n" +
                "I can help you learn about phishing, passwords, suspicious links, " +
                "malware, and social engineering.\n\n" +
                "To get started, tell me your name or click a topic on the left!");

            // Focus the input box so the user can type immediately
            InputBox.Focus();
        }

        // ---------------------------------------------------------------
        // LOAD ASCII ART
        // Reads ascii-art.txt from the Audio folder and displays it
        // in the sidebar TextBlock using Consolas monospace font.
        // Falls back to a built-in banner if the file is missing.
        // ---------------------------------------------------------------
        private void LoadAsciiArt()
        {
            string path = "Audio/goose.txt";

            if (File.Exists(path))
            {
                try
                {
                    AsciiArtBlock.Text = File.ReadAllText(path);
                    return;
                }
                catch { /* fall through to built-in */ }
            }

            // Built-in fallback banner
            AsciiArtBlock.Text =

                "  ______      __              ____        __ \n" +
                " / ____/_  __/ /_  ___  _____/ __ )____  / /_\n" +
                "/ /   / / / / __ \\/ _ \\/ ___/ __  / __ \\/ __/\n" +
                "\\____/\\__, /_.___/\\___/_/  /_____/\\____/\\__/ \n" +
                "     /____/                                    ";
        }

        // ---------------------------------------------------------------
        // SEND BUTTON CLICK
        // ---------------------------------------------------------------
        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        // ---------------------------------------------------------------
        // INPUT BOX KEY DOWN  (Enter = send)
        // ---------------------------------------------------------------
        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !string.IsNullOrWhiteSpace(InputBox.Text))
            {
                SendMessage();
                e.Handled = true;
            }
        }

        // ---------------------------------------------------------------
        // INPUT BOX TEXT CHANGED  (enable/disable send button)
        // ---------------------------------------------------------------
        private void InputBox_TextChanged(object sender,
            System.Windows.Controls.TextChangedEventArgs e)
        {
            SendButton.IsEnabled = !string.IsNullOrWhiteSpace(InputBox.Text);
        }

        // ---------------------------------------------------------------
        // TOPIC BUTTON CLICK  (sidebar quick-access buttons)
        // Sends the button's Tag value as a message
        // ---------------------------------------------------------------
        private void TopicButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag is string tag)
            {
                InputBox.Text = tag;
                SendMessage();
            }
        }

        // ---------------------------------------------------------------
        // CLEAR CHAT CLICK
        // ---------------------------------------------------------------
        private void ClearChat_Click(object sender, RoutedEventArgs e)
        {
            _messages.Clear();
            AddBotMessage("Chat cleared! I still remember what you've told me. " +
                          "What would you like to talk about?");
        }

        // ---------------------------------------------------------------
        // SEND MESSAGE
        // Core method: adds user message, triggers bot response.
        // ---------------------------------------------------------------
        private void SendMessage()
        {
            string userText = InputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(userText)) return;

            // Clear input immediately
            InputBox.Clear();

            // Add user bubble
            AddUserMessage(userText);

            // Show typing indicator
            TypingIndicator.Visibility = Visibility.Visible;
            SendButton.IsEnabled = false;

            // Get the bot's response (this is fast — no API call needed)
            Sentiment sentiment;
            string response = _engine.ProcessInput(userText, out sentiment);

            // Store pending response and start the typing timer
            _pendingResponse = response;
            _typingTimer.Start();

            // Update sentiment indicator in sidebar
            UpdateSentimentDisplay(sentiment);

            // Update topic label in header
            string topicName = _engine.Context.GetTopicName();
            TopicLabel.Text = topicName.Length > 0 ? $"📌 {topicName}" : "";

            // Update memory display in sidebar
            UpdateMemoryDisplay();
        }

        // ---------------------------------------------------------------
        // TYPING TIMER TICK
        // Fires after the delay — hides typing indicator, shows response.
        // ---------------------------------------------------------------
        private void TypingTimer_Tick(object? sender, EventArgs e)
        {
            _typingTimer.Stop();
            TypingIndicator.Visibility = Visibility.Collapsed;
            SendButton.IsEnabled = true;

            AddBotMessage(_pendingResponse);
        }

        // ---------------------------------------------------------------
        // ADD BOT MESSAGE
        // ---------------------------------------------------------------
        private void AddBotMessage(string text)
        {
            _messages.Add(new ChatMessage
            {
                Text      = text,
                IsBot     = true,
                Timestamp = DateTime.Now.ToString("HH:mm")
            });
            ScrollToBottom();
        }

        // ---------------------------------------------------------------
        // ADD USER MESSAGE
        // ---------------------------------------------------------------
        private void AddUserMessage(string text)
        {
            _messages.Add(new ChatMessage
            {
                Text      = text,
                IsBot     = false,
                Timestamp = DateTime.Now.ToString("HH:mm")
            });
            ScrollToBottom();
        }

        // ---------------------------------------------------------------
        // SCROLL TO BOTTOM
        // Ensures the latest message is always visible.
        // ---------------------------------------------------------------
        private void ScrollToBottom()
        {
            // Dispatcher ensures this runs after the UI has updated
            Dispatcher.InvokeAsync(() =>
            {
                ChatScrollViewer.ScrollToBottom();
            }, DispatcherPriority.Background);
        }

        // ---------------------------------------------------------------
        // UPDATE SENTIMENT DISPLAY
        // Shows the detected mood in the sidebar.
        // ---------------------------------------------------------------
        private void UpdateSentimentDisplay(Sentiment sentiment)
        {
            string label = SentimentDetector.GetLabel(sentiment);
            SentimentBlock.Text = label.Length > 0 ? label : "—";
        }

        // ---------------------------------------------------------------
        // UPDATE MEMORY DISPLAY
        // Shows what the bot currently remembers in the sidebar.
        // ---------------------------------------------------------------
        private void UpdateMemoryDisplay()
        {
            var mem = _engine.Memory;

            if (!mem.HasAnyMemory())
            {
                MemoryBlock.Text = "Nothing remembered yet.\nTell me your name!";
                return;
            }

            var lines = new System.Text.StringBuilder();
            if (mem.UserName    != null) lines.AppendLine($"👤 {mem.UserName}");
            if (mem.UserJob     != null) lines.AppendLine($"💼 {mem.UserJob}");
            if (mem.UserConcern != null) lines.AppendLine($"😟 Concerned: {mem.UserConcern}");

            MemoryBlock.Text = lines.ToString().Trim();
        }
    }
}
