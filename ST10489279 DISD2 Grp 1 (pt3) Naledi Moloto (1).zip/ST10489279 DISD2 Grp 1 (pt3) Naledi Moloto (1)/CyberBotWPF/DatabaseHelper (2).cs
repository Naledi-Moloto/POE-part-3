using System;
using System.Collections.Generic;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace CybersecurityChatbot
{
    public class TaskItem
    {
        public int       Id          { get; set; }
        public string    Title       { get; set; }
        public string    Description { get; set; }
        public DateTime? Reminder    { get; set; }
        public bool      IsCompleted { get; set; }
        public DateTime  CreatedAt   { get; set; }

        // Formatted reminder string for display in the task list
        public string ReminderDisplay => Reminder.HasValue
            ? Reminder.Value.ToString("MMM dd, yyyy  HH:mm")
            : "No reminder set";
    }

    public class ActivityEntry
    {
        public int      Id          { get; set; }
        public string   Action      { get; set; }
        public string   Description { get; set; }
        public DateTime LoggedAt    { get; set; }
    }

    public static class DatabaseHelper
    {
        // ------------------------------------------------------------------
        // Connection string – reads from App.config first, falls back to
        // the hard-coded value.  Only the Password field needs changing.
        // ------------------------------------------------------------------
        private static string _connectionString;

        static DatabaseHelper()
        {
            try
            {
                // Try App.config first
                var cs = ConfigurationManager.ConnectionStrings["CyberbotDB"];
                if (cs != null && !string.IsNullOrWhiteSpace(cs.ConnectionString))
                {
                    _connectionString = cs.ConnectionString;
                    return;
                }
            }
            catch { }

            // Hard-coded fallback – replace YOUR_PASSWORD_HERE with your MySQL password
            _connectionString =
                "Server=localhost;Port=3306;Database=cybersecurity_chatbot;" +
                "User Id=root;Password=YOUR_PASSWORD_HERE;" +
                "SslMode=none;CharSet=utf8mb4;AllowZeroDateTime=true;ConvertZeroDateTime=true;";
        }

        private static MySqlConnection GetConnection()
            => new MySqlConnection(_connectionString);

        // ------------------------------------------------------------------
        //  CONNECTION TEST  – called at startup to set the DB status label
        // ------------------------------------------------------------------
        public static bool TestConnection(out string error)
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    // Verify the table actually exists
                    var cmd = new MySqlCommand(
                        "SELECT COUNT(*) FROM information_schema.tables " +
                        "WHERE table_schema='cybersecurity_chatbot' AND table_name='tasks';", conn);
                    cmd.ExecuteScalar();
                    error = null;
                    return true;
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        // ==================================================================
        //  TASKS
        // ==================================================================
        public static List<TaskItem> GetAllTasks()
        {
            var list = new List<TaskItem>();
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "SELECT id, title, description, reminder, is_completed, created_at " +
                    "FROM tasks ORDER BY created_at DESC;", conn);

                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new TaskItem
                        {
                            Id          = r.GetInt32("id"),
                            Title       = r.GetString("title"),
                            Description = r.IsDBNull(r.GetOrdinal("description"))
                                          ? string.Empty : r.GetString("description"),
                            Reminder    = r.IsDBNull(r.GetOrdinal("reminder"))
                                          ? (DateTime?)null : r.GetDateTime("reminder"),
                            IsCompleted = r.GetBoolean("is_completed"),
                            CreatedAt   = r.GetDateTime("created_at")
                        });
                    }
                }
            }
            return list;
        }

        public static int AddTask(string title, string description, DateTime? reminder)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "INSERT INTO tasks (title, description, reminder) " +
                    "VALUES (@title, @desc, @reminder); SELECT LAST_INSERT_ID();", conn);

                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@desc",
                    string.IsNullOrWhiteSpace(description) ? (object)DBNull.Value : description);
                cmd.Parameters.AddWithValue("@reminder",
                    reminder.HasValue ? (object)reminder.Value : DBNull.Value);

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public static void MarkTaskCompleted(int taskId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "UPDATE tasks SET is_completed=1 WHERE id=@id;", conn);
                cmd.Parameters.AddWithValue("@id", taskId);
                cmd.ExecuteNonQuery();
            }
        }

        public static void DeleteTask(int taskId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand("DELETE FROM tasks WHERE id=@id;", conn);
                cmd.Parameters.AddWithValue("@id", taskId);
                cmd.ExecuteNonQuery();
            }
        }

        // ==================================================================
        //  ACTIVITY LOG
        // ==================================================================
        public static void LogActivity(string action, string description)
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    var cmd = new MySqlCommand(
                        "INSERT INTO activity_log (action, description) VALUES (@a, @d);", conn);
                    cmd.Parameters.AddWithValue("@a", action);
                    cmd.Parameters.AddWithValue("@d", description ?? string.Empty);
                    cmd.ExecuteNonQuery();
                }
            }
            catch { /* never crash on logging */ }
        }

        public static List<ActivityEntry> GetRecentLog(int limit = 10)
        {
            var list = new List<ActivityEntry>();
            using (var conn = GetConnection())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "SELECT id, action, description, logged_at " +
                    "FROM activity_log ORDER BY logged_at DESC LIMIT @limit;", conn);
                cmd.Parameters.AddWithValue("@limit", limit);

                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new ActivityEntry
                        {
                            Id          = r.GetInt32("id"),
                            Action      = r.GetString("action"),
                            Description = r.IsDBNull(r.GetOrdinal("description"))
                                          ? string.Empty : r.GetString("description"),
                            LoggedAt    = r.GetDateTime("logged_at")
                        });
                    }
                }
            }
            return list;
        }

        // ==================================================================
        //  QUIZ RESULTS
        // ==================================================================
        public static void SaveQuizResult(int score, int total)
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    var cmd = new MySqlCommand(
                        "INSERT INTO quiz_results (score, total) VALUES (@s, @t);", conn);
                    cmd.Parameters.AddWithValue("@s", score);
                    cmd.Parameters.AddWithValue("@t", total);
                    cmd.ExecuteNonQuery();
                }
            }
            catch { }
        }
    }
}
