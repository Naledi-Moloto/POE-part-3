// =======================================================================
// ConversationContext.cs  -  Bot/
// -----------------------------------------------------------------------
// Tracks the current topic so the bot can handle follow-up questions
// like "give me another tip", "tell me more", or "explain that again"
// without losing context of what was being discussed.
// =======================================================================

namespace CyberBotWPF.Bot
{
    public enum Topic
    {
        None,
        Phishing,
        Password,
        Links,
        Malware,
        SocialEngineering
    }

    public enum SubTopic
    {
        None,
        Definition,
        RedFlags,
        Tips,
        Scenario,
        Types,
        Passphrase,
        BadPasswords,
        BackupRule,
        Tactics,
        Exercise
    }

    public class ConversationContext
    {
        // The topic currently being discussed
        public Topic CurrentTopic { get; set; } = Topic.None;

        // The last sub-topic that was shown
        public SubTopic LastSubTopic { get; set; } = SubTopic.None;

        // How many times the current topic has been continued
        public int FollowUpCount { get; set; } = 0;

        // The index of the last response shown (for "give me another")
        public int LastResponseIndex { get; set; } = 0;

        // ---------------------------------------------------------------
        // SET TOPIC
        // Updates the current topic and resets follow-up tracking.
        // ---------------------------------------------------------------
        public void SetTopic(Topic topic, SubTopic subTopic = SubTopic.None)
        {
            // Only reset follow-up count if this is a NEW topic
            if (topic != CurrentTopic)
            {
                FollowUpCount = 0;
                LastResponseIndex = 0;
            }

            CurrentTopic  = topic;
            LastSubTopic  = subTopic;
        }

        // ---------------------------------------------------------------
        // IS FOLLOW UP
        // Returns true if the input looks like a follow-up to the
        // current topic rather than a brand new question.
        // ---------------------------------------------------------------
        public bool IsFollowUp(string input)
        {
            if (CurrentTopic == Topic.None) return false;

            string lower = input.ToLower().Trim();

            string[] followUpKeywords =
            {
                "another", "more", "again", "else", "other",
                "tell me more", "give me more", "explain more",
                "what else", "any more", "keep going",
                "expand", "elaborate", "continue", "go on",
                "next tip", "another tip", "one more",
                "different", "something else about"
            };

            foreach (string kw in followUpKeywords)
                if (lower.Contains(kw)) return true;

            return false;
        }

        // ---------------------------------------------------------------
        // BUMP FOLLOW UP COUNT
        // ---------------------------------------------------------------
        public void BumpFollowUp()
        {
            FollowUpCount++;
        }

        // ---------------------------------------------------------------
        // GET TOPIC DISPLAY NAME
        // ---------------------------------------------------------------
        public string GetTopicName()
        {
            return CurrentTopic switch
            {
                Topic.Phishing          => "Phishing",
                Topic.Password          => "Passwords",
                Topic.Links             => "Suspicious Links",
                Topic.Malware           => "Malware",
                Topic.SocialEngineering => "Social Engineering",
                _                       => ""
            };
        }
    }
}
