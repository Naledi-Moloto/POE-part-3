// =======================================================================
// AudioPlayer.cs  -  Bot/
// -----------------------------------------------------------------------
// Plays the recorded WAV voice greeting when the app launches.
// =======================================================================

using System.Media;
using System.IO;

namespace CyberBotWPF.Bot
{
    public static class AudioPlayer
    {
        private static readonly string GreetingPath = "Audio/greeting.wav";

        // ---------------------------------------------------------------
        // PLAY GREETING
        // Plays the WAV file asynchronously so it does not block the UI.
        // ---------------------------------------------------------------
        public static void PlayGreetingAsync()
        {
            if (!File.Exists(GreetingPath)) return;

            try
            {
                // Run on a background thread so UI stays responsive
                Task.Run(() =>
                {
                    using SoundPlayer player = new SoundPlayer(GreetingPath);
                    player.PlaySync();
                });
            }
            catch
            {
                // Silently skip if audio fails
            }
        }
    }
}
