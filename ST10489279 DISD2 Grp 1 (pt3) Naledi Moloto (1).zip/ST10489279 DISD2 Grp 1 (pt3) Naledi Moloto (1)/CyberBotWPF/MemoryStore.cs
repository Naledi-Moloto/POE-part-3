// =======================================================================
// MemoryStore.cs  -  Bot/
// -----------------------------------------------------------------------
// Stores information the user shares during the conversation so the
// bot can refer back to it later (name, job, concerns, etc.)
// =======================================================================

namespace CyberBotWPF.Bot
{
    public class MemoryStore
    {
        // -- Stored user details --
        public string? UserName     { get; private set; }
        public string? UserJob      { get; private set; }
        public string? UserConcern  { get; private set; }

        // General key-value memory for anything else the user shares
        private readonly Dictionary<string, string> _generalMemory = new();

        // ---------------------------------------------------------------
        // TRY EXTRACT AND STORE
        // Called on every message. Looks for personal detail patterns.
        // Returns true if something new was stored.
        // ---------------------------------------------------------------
        public bool TryExtractAndStore(string input)
        {
            string lower = input.ToLower().Trim();
            bool stored = false;

            // -- Name detection --
            // "my name is X"  /  "i am X"  /  "call me X"
            if (UserName == null)
            {
                string? name = ExtractAfter(lower, new[]
                {
                    "my name is ", "i am ", "call me ", "i'm "
                });
                if (name != null && name.Length > 1 && name.Length < 30
                    && !ContainsCyberKeyword(name))
                {
                    // Capitalise the first letter
                    UserName = char.ToUpper(name[0]) + name.Substring(1);
                    stored = true;
                }
            }

            // -- Job/role detection --
            // "i work as X"  /  "i am a X"  /  "i'm a X"
            if (UserJob == null)
            {
                string? job = ExtractAfter(lower, new[]
                {
                    "i work as ", "i work in ", "i am a ", "i'm a ",
                    "my job is ", "my role is "
                });
                if (job != null && job.Length > 2 && !ContainsCyberKeyword(job))
                {
                    UserJob = job;
                    stored = true;
                }
            }

            // -- Concern detection --
            // "i'm worried about X"  /  "i'm concerned about X"
            if (UserConcern == null)
            {
                string? concern = ExtractAfter(lower, new[]
                {
                    "worried about ", "concerned about ",
                    "scared of ", "afraid of ", "nervous about "
                });
                if (concern != null && concern.Length > 2)
                {
                    UserConcern = concern;
                    stored = true;
                }
            }

            return stored;
        }

        // ---------------------------------------------------------------
        // STORE GENERAL FACT
        // Lets other classes manually store a key-value pair.
        // ---------------------------------------------------------------
        public void Store(string key, string value)
        {
            _generalMemory[key] = value;
        }

        // ---------------------------------------------------------------
        // GET
        // Retrieves a stored value by key, or null if not found.
        // ---------------------------------------------------------------
        public string? Get(string key)
        {
            return _generalMemory.TryGetValue(key, out string? val) ? val : null;
        }

        // ---------------------------------------------------------------
        // BUILD PERSONAL GREETING PREFIX
        // Returns a personalised prefix if we know the user's name.
        // ---------------------------------------------------------------
        public string PersonalPrefix()
        {
            if (UserName != null)
                return $"Here you go, {UserName} — ";
            return "";
        }

        // ---------------------------------------------------------------
        // HAS ANY MEMORY
        // Returns true if we know at least something about the user.
        // ---------------------------------------------------------------
        public bool HasAnyMemory()
        {
            return UserName != null || UserJob != null || UserConcern != null
                   || _generalMemory.Count > 0;
        }

        // ---------------------------------------------------------------
        // SUMMARISE MEMORY  (used in "what do you know about me?" replies)
        // ---------------------------------------------------------------
        public string SummariseMemory()
        {
            var parts = new List<string>();
            if (UserName    != null) parts.Add($"Your name is {UserName}");
            if (UserJob     != null) parts.Add($"you work as {UserJob}");
            if (UserConcern != null) parts.Add($"you mentioned being concerned about {UserConcern}");
            foreach (var kv in _generalMemory)
                parts.Add($"{kv.Key}: {kv.Value}");

            return parts.Count == 0
                ? "I don't know much about you yet — feel free to tell me your name!"
                : string.Join(", and ", parts) + ".";
        }

        // ---------------------------------------------------------------
        // PRIVATE HELPERS
        // ---------------------------------------------------------------

        // Extracts the word(s) after any of the given prefixes
        private static string? ExtractAfter(string input, string[] prefixes)
        {
            foreach (string prefix in prefixes)
            {
                int idx = input.IndexOf(prefix);
                if (idx >= 0)
                {
                    string after = input.Substring(idx + prefix.Length).Trim();
                    // Take only the first 1-3 words
                    string[] words = after.Split(' ');
                    string result = string.Join(" ", words.Take(3)).Trim('.',',','!','?','"','\'');
                    if (result.Length > 0) return result;
                }
            }
            return null;
        }

        // Makes sure we don't accidentally store cybersecurity keywords as names
        private static bool ContainsCyberKeyword(string text)
        {
            string[] keywords = { "phishing", "password", "malware", "virus",
                                   "link", "social", "cyber", "security",
                                   "hacker", "attack", "scam", "worried",
                                   "curious", "frustrated", "concerned" };
            foreach (string kw in keywords)
                if (text.Contains(kw)) return true;
            return false;
        }
    }
}
