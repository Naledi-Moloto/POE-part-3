// =======================================================================
// Converters.cs  -  Converters/
// -----------------------------------------------------------------------
// WPF value converters used in XAML data bindings.
// These allow the UI to automatically adjust based on whether a
// message is from the bot or the user.
// =======================================================================

using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace CyberBotWPF.Converters
{
    // ---------------------------------------------------------------
    // BOOL TO HORIZONTAL ALIGNMENT
    // IsBot=true  -> Left  (bot bubbles on the left)
    // IsBot=false -> Right (user bubbles on the right)
    // ---------------------------------------------------------------
    public class BoolToAlignmentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
                              object parameter, CultureInfo culture)
        {
            bool isBot = (bool)value;
            return isBot ? HorizontalAlignment.Left : HorizontalAlignment.Right;
        }

        public object ConvertBack(object value, Type targetType,
                                  object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    // ---------------------------------------------------------------
    // BOOL TO BUBBLE BACKGROUND COLOUR
    // IsBot=true  -> Dark card colour  #1C2333
    // IsBot=false -> Cyan accent       #00B4D8
    // ---------------------------------------------------------------
    public class BoolToBubbleColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
                              object parameter, CultureInfo culture)
        {
            bool isBot = (bool)value;
            return isBot
                ? new SolidColorBrush(Color.FromRgb(0x1C, 0x23, 0x33))   // bot: dark card
                : new SolidColorBrush(Color.FromRgb(0x00, 0x3D, 0x5C));  // user: dark cyan
        }

        public object ConvertBack(object value, Type targetType,
                                  object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    // ---------------------------------------------------------------
    // BOOL TO TEXT COLOUR
    // IsBot=true  -> White text
    // IsBot=false -> Light cyan text
    // ---------------------------------------------------------------
    public class BoolToTextColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
                              object parameter, CultureInfo culture)
        {
            bool isBot = (bool)value;
            return isBot
                ? new SolidColorBrush(Color.FromRgb(0xF0, 0xF6, 0xFC))  // white
                : new SolidColorBrush(Color.FromRgb(0x00, 0xB4, 0xD8));  // cyan
        }

        public object ConvertBack(object value, Type targetType,
                                  object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    // ---------------------------------------------------------------
    // BOOL TO SENDER LABEL COLOUR
    // IsBot=true  -> Cyan  (CyberBot label)
    // IsBot=false -> Green (You label)
    // ---------------------------------------------------------------
    public class BoolToLabelColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
                              object parameter, CultureInfo culture)
        {
            bool isBot = (bool)value;
            return isBot
                ? new SolidColorBrush(Color.FromRgb(0x00, 0xB4, 0xD8))  // cyan
                : new SolidColorBrush(Color.FromRgb(0x3D, 0xDC, 0x84)); // green
        }

        public object ConvertBack(object value, Type targetType,
                                  object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    // ---------------------------------------------------------------
    // BOOL TO CORNER RADIUS
    // IsBot=true  -> rounded top-right corner (bot bubble shape)
    // IsBot=false -> rounded top-left  corner (user bubble shape)
    // ---------------------------------------------------------------
    public class BoolToCornerRadiusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
                              object parameter, CultureInfo culture)
        {
            bool isBot = (bool)value;
            // Bot:  flat top-left, rounded elsewhere
            // User: rounded top-left, flat top-right
            return isBot
                ? new CornerRadius(2, 12, 12, 12)
                : new CornerRadius(12, 2, 12, 12);
        }

        public object ConvertBack(object value, Type targetType,
                                  object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
