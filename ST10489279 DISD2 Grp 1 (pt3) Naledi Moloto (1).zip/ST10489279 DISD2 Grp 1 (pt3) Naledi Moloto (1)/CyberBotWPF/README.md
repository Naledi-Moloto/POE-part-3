# CyberBotWPF — Cybersecurity Awareness Chatbot (Part 2)

A WPF desktop application built in C# for Visual Studio 2022.

---

## How to Open in Visual Studio 2022

1. Open Visual Studio 2022
2. Click "Open a project or solution"
3. Navigate to the CyberBotWPF/ folder
4. Select **CyberBotWPF.csproj** and click Open
5. Press **F5** to build and run

---

## Project Structure

```
CyberBotWPF/
├── App.xaml                    <- Global colours, styles, themes
├── App.xaml.cs
├── MainWindow.xaml             <- Full GUI layout
├── MainWindow.xaml.cs          <- UI logic and event handlers
├── CyberBotWPF.csproj
│
├── Audio/                      <- DROP YOUR FILES HERE
│   ├── greeting.wav            <- Your recorded WAV greeting
│   └── ascii-art.txt          <- Your ASCII art text file
│
├── Bot/
│   ├── AudioPlayer.cs          <- Plays greeting.wav on startup
│   ├── ChatEngine.cs           <- Main brain — routes all input
│   ├── ConversationContext.cs  <- Tracks topic for follow-up questions
│   ├── MemoryStore.cs          <- Remembers user name, job, concern
│   ├── ResponseLibrary.cs      <- All responses as lists (random selection)
│   └── SentimentDetector.cs    <- Detects worried/curious/frustrated etc.
│
├── Converters/
│   └── Converters.cs           <- WPF data binding helpers
│
└── Models/
    └── ChatMessage.cs          <- Single chat bubble data model
```

---

## Adding Your Files

### Voice Greeting (WAV)
1. Save your recording as `greeting.wav`
2. Drop it into `CyberBotWPF/Audio/`
3. In Visual Studio: right-click the file → Properties
   → Set "Copy to Output Directory" = "Copy if newer"
4. Run — it plays automatically on startup

### ASCII Art
1. Save your ASCII art as `ascii-art.txt`
2. Drop it into `CyberBotWPF/Audio/`
3. Same "Copy if newer" setting in Properties
4. Run — it displays in the sidebar automatically

---

## Features

| Feature | Details |
|---|---|
| Chat bubbles | Left = bot (dark), Right = user (cyan) |
| Random responses | Each topic has 5-6 responses, one chosen at random |
| Follow-up questions | "Give me another tip" / "Tell me more" works seamlessly |
| Memory recall | Bot remembers your name, job, concern |
| Sentiment detection | Adjusts tone for worried/curious/frustrated/grateful |
| Topic buttons | Sidebar buttons jump to any topic instantly |
| Typing indicator | Bot shows "typing..." before responding |
| Mood display | Current sentiment shown in sidebar |
| ASCII art sidebar | Your image displayed in the left panel |
| WAV greeting | Plays on startup automatically |

---

## What You Can Say

| Input | Response |
|---|---|
| "hi" / "hello" / "good morning" | Random greeting |
| "My name is [name]" | Bot remembers and uses your name |
| "Give me a phishing tip" | Random tip from the list |
| "Give me another tip" | Different tip from same topic |
| "What is phishing?" | Definition only |
| "Phishing red flags" | Warning signs only |
| "I'm worried about malware" | Empathetic response prefix |
| "What do you remember about me?" | Memory summary |
| "help" | Full topic menu |
| Click sidebar buttons | Jump directly to any topic |
