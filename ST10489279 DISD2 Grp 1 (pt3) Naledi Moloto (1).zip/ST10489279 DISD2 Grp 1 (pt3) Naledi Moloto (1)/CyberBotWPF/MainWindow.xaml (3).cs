using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace CybersecurityChatbot
{
    public partial class MainWindow : Window
    {
        private static readonly SolidColorBrush BrushBot    = new SolidColorBrush(Color.FromRgb(0x1F, 0x29, 0x37));
        private static readonly SolidColorBrush BrushUser   = new SolidColorBrush(Color.FromRgb(0x00, 0x5C, 0x3A));
        private static readonly SolidColorBrush BrushSystem = new SolidColorBrush(Color.FromRgb(0x16, 0x1B, 0x27));
        private static readonly SolidColorBrush BrushGreen  = new SolidColorBrush(Color.FromRgb(0x00, 0xFF, 0x9C));
        private static readonly SolidColorBrush BrushGrey   = new SolidColorBrush(Color.FromRgb(0x6B, 0x72, 0x80));
        private static readonly SolidColorBrush BrushWhite  = new SolidColorBrush(Colors.White);

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        // ==================================================================
        //  STARTUP
        // ==================================================================
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (DatabaseHelper.TestConnection(out string dbError))
            {
                TxtDbStatus.Text       = "● DB: Connected";
                TxtDbStatus.Foreground = BrushGreen;
                ActivityLogger.Log("APP_START", "Application started. Database connected.");
            }
            else
            {
                TxtDbStatus.Text       = "● DB: Offline";
                TxtDbStatus.Foreground = new SolidColorBrush(Color.FromRgb(0xFF, 0x4C, 0x4C));
                ActivityLogger.Log("APP_START", $"DB offline: {dbError}");
                AddSystemMessage(
                    "⚠️ Database not connected. Task features will be unavailable.\n" +
                    "Fix: Open DatabaseHelper.cs and replace YOUR_PASSWORD_HERE with your MySQL password, " +
                    "then ensure MySQL Server is running (check Windows Services for MySQL80).");
            }

            AddBotMessage(ResponseBank.Greeting());
            AddBotMessage(
                "I can help with cybersecurity topics, tasks, and quizzes.\n" +
                "💡 Try typing a topic like 'phishing' or 'passwords', then type 'more' for definitions, examples and tips!\n" +
                "Type 'help' to see all commands.");
        }

        // ==================================================================
        //  INPUT
        // ==================================================================
        private void TxtInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !Keyboard.IsKeyDown(Key.LeftShift))
            {
                e.Handled = true;
                ProcessInput();
            }
        }

        private void BtnSend_Click(object sender, RoutedEventArgs e) => ProcessInput();

        private void Chip_Click(object sender, RoutedEventArgs e)
        {
            TxtInput.Text = ((Button)sender).Tag?.ToString() ?? string.Empty;
            ProcessInput();
        }

        private void TopicBtn_Click(object sender, RoutedEventArgs e)
        {
            TxtInput.Text = ((Button)sender).Tag?.ToString() ?? string.Empty;
            ProcessInput();
        }

        private void SideChat_Click(object sender, RoutedEventArgs e)  => TxtInput.Focus();
        private void SideTasks_Click(object sender, RoutedEventArgs e) => OpenTaskManager();
        private void SideQuiz_Click(object sender, RoutedEventArgs e)  => OpenQuiz();
        private void SideLog_Click(object sender, RoutedEventArgs e)
        {
            TxtInput.Text = "activity log";
            ProcessInput();
        }

        private void BtnClearChat_Click(object sender, RoutedEventArgs e)
        {
            ChatPanel.Children.Clear();
            AddSystemMessage("Chat cleared. How can I help you?");
        }

        // ==================================================================
        //  CORE DISPATCH
        // ==================================================================
        private void ProcessInput()
        {
            string raw = TxtInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(raw)) return;

            AddUserMessage(raw);
            TxtInput.Text = string.Empty;

            NlpResult nlp = NlpEngine.Analyse(raw);
            DispatchIntent(nlp, raw);
            ScrollToBottom();
        }

        private void DispatchIntent(NlpResult nlp, string raw)
        {
            switch (nlp.Intent)
            {
                // ── Conversational ──────────────────────────────────────
                case Intent.Greeting:
                    AddBotMessage(ResponseBank.Greeting());
                    ActivityLogger.Log("CHAT", "User greeted the bot.");
                    break;

                case Intent.Farewell:
                    AddBotMessage(ResponseBank.Farewell());
                    ActivityLogger.Log("CHAT", "User said farewell.");
                    break;

                case Intent.Help:
                    AddBotMessage(ResponseBank.Help());
                    ActivityLogger.Log("HELP_VIEWED", "User viewed help menu.");
                    break;

                // ── More / continuation ─────────────────────────────────
                case Intent.More:
                    AddBotMessage(ResponseBank.GetMoreResponse());
                    ActivityLogger.Log("MORE", "User requested more info on current topic.");
                    break;

                // ── Tasks ───────────────────────────────────────────────
                case Intent.AddTask:
                case Intent.ViewTasks:
                case Intent.DeleteTask:
                case Intent.CompleteTask:
                    AddBotMessage(ResponseBank.OpeningTaskManager());
                    OpenTaskManager();
                    ActivityLogger.Log("TASK_OPEN", "Task Manager opened.");
                    break;

                // ── Quiz ────────────────────────────────────────────────
                case Intent.StartQuiz:
                    AddBotMessage(ResponseBank.StartingQuiz());
                    OpenQuiz();
                    break;

                // ── Activity log ────────────────────────────────────────
                case Intent.ViewLog:
                    ShowActivityLog();
                    break;

                // ── Cybersecurity topics ─────────────────────────────────
                case Intent.Phishing:
                    AddBotMessage(ResponseBank.GetTopicResponse("phishing"));
                    ActivityLogger.Log("TOPIC", "User asked about phishing.");
                    break;

                case Intent.Password:
                    AddBotMessage(ResponseBank.GetTopicResponse("password"));
                    ActivityLogger.Log("TOPIC", "User asked about passwords.");
                    break;

                case Intent.Malware:
                    AddBotMessage(ResponseBank.GetTopicResponse("malware"));
                    ActivityLogger.Log("TOPIC", "User asked about malware.");
                    break;

                case Intent.SocialEngineering:
                    AddBotMessage(ResponseBank.GetTopicResponse("social engineering"));
                    ActivityLogger.Log("TOPIC", "User asked about social engineering.");
                    break;

                case Intent.SuspiciousLink:
                    AddBotMessage(ResponseBank.GetTopicResponse("suspicious link"));
                    ActivityLogger.Log("TOPIC", "User asked about suspicious links.");
                    break;

                case Intent.Privacy:
                    AddBotMessage(ResponseBank.GetTopicResponse("privacy"));
                    ActivityLogger.Log("TOPIC", "User asked about privacy.");
                    break;

                case Intent.TwoFactorAuth:
                    AddBotMessage(ResponseBank.GetTopicResponse("two factor"));
                    ActivityLogger.Log("TOPIC", "User asked about 2FA.");
                    break;

                case Intent.PublicWifi:
                    AddBotMessage(ResponseBank.GetTopicResponse("public wifi"));
                    ActivityLogger.Log("TOPIC", "User asked about public Wi-Fi.");
                    break;

                case Intent.Ransomware:
                    AddBotMessage(ResponseBank.GetTopicResponse("ransomware"));
                    ActivityLogger.Log("TOPIC", "User asked about ransomware.");
                    break;

                // ── Sentiment ───────────────────────────────────────────
                case Intent.PositiveSentiment:
                    AddBotMessage(ResponseBank.PositiveSentiment());
                    break;

                case Intent.NegativeSentiment:
                    AddBotMessage(ResponseBank.NegativeSentiment());
                    break;

                default:
                    AddBotMessage(ResponseBank.Unknown());
                    ActivityLogger.Log("UNKNOWN", $"Unrecognised: '{raw}'");
                    break;
            }
        }

        // ==================================================================
        //  FEATURE LAUNCHERS
        // ==================================================================
        private void OpenTaskManager()
        {
            var win = new TaskManagerWindow { Owner = this };
            win.ShowDialog();
            ActivityLogger.Log("TASK_MANAGER", "Task Manager window closed.");
        }

        private void OpenQuiz()
        {
            ActivityLogger.Log("QUIZ_OPENED", "Quiz window opened.");
            var win = new QuizWindow { Owner = this };
            win.ShowDialog();
        }

        private void ShowActivityLog()
        {
            AddBotMessage(ActivityLogger.GetFormattedLog(10));
            ActivityLogger.Log("LOG_VIEWED", "User viewed activity log.");
        }

        // ==================================================================
        //  CHAT BUBBLE BUILDER
        // ==================================================================
        private void AddUserMessage(string text) =>
            ChatPanel.Children.Add(MakeBubble(text, BrushUser,
                HorizontalAlignment.Right, BrushWhite, "You"));

        private void AddBotMessage(string text) =>
            ChatPanel.Children.Add(MakeBubble(text, BrushBot,
                HorizontalAlignment.Left, BrushWhite, "🛡️ Goose"));

        private void AddSystemMessage(string text) =>
            ChatPanel.Children.Add(MakeBubble(text, BrushSystem,
                HorizontalAlignment.Center, BrushGrey, null));

        private static UIElement MakeBubble(
            string text,
            SolidColorBrush bg,
            HorizontalAlignment align,
            SolidColorBrush fg,
            string label)
        {
            var outer = new StackPanel
            {
                HorizontalAlignment = align,
                Margin  = new Thickness(0, 4, 0, 4),
                MaxWidth = 600
            };

            if (!string.IsNullOrEmpty(label))
                outer.Children.Add(new TextBlock
                {
                    Text       = label,
                    FontSize   = 10,
                    Foreground = new SolidColorBrush(Color.FromRgb(0x6B, 0x72, 0x80)),
                    Margin     = new Thickness(4, 0, 4, 2),
                    HorizontalAlignment = align == HorizontalAlignment.Right
                                          ? HorizontalAlignment.Right
                                          : HorizontalAlignment.Left
                });

            var border = new Border
            {
                Background   = bg,
                CornerRadius = new CornerRadius(12),
                Padding      = new Thickness(14, 10, 14, 10)
            };

            border.Child = new TextBlock
            {
                Text         = text,
                Foreground   = fg,
                TextWrapping = TextWrapping.Wrap,
                FontSize     = 13,
                LineHeight   = 20
            };

            outer.Children.Add(border);
            return outer;
        }

        private void ScrollToBottom() =>
            Dispatcher.InvokeAsync(
                () => ChatScroll.ScrollToEnd(),
                System.Windows.Threading.DispatcherPriority.Loaded);
    }
}
