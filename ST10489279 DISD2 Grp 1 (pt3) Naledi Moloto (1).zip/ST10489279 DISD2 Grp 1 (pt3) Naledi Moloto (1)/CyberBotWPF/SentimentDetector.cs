// =======================================================================
// SentimentDetector.cs  -  Bot/
// -----------------------------------------------------------------------
// Detects the emotional tone of the user's message and returns
// an empathetic response prefix so the bot can adjust its tone.
//
// Sentiments detected:
//   Worried    - scared, worried, nervous, anxious, afraid
//   Frustrated - annoyed, frustrated, confused, don't understand
//   Curious    - interesting, wonder, curious, want to know, tell me more
//   Grateful   - thanks, thank you, appreciate, helpful
//   Positive   - great, awesome, cool, love, amazing
//   Neutral    - (default, no sentiment detected)
// =======================================================================

namespace CyberBotWPF.Bot
{
    public enum Sentiment
    {
        Neutral,
        Worried,
        Frustrated,
        Curious,
        Grateful,
        Positive
    }

    public static class SentimentDetector
    {
        // ---------------------------------------------------------------
        // KEYWORD LISTS per sentiment
        // ---------------------------------------------------------------

        private static readonly string[] WorriedKeywords =
        {
            "worried", "scared", "nervous", "anxious", "afraid",
            "frighten", "panic", "terrified", "unsafe", "vulnerable",
            "at risk", "danger", "help me", "what if", "could happen"
        };

        private static readonly string[] FrustratedKeywords =
        {
            "frustrated", "annoyed", "confus", "don't understand",
            "dont understand", "makes no sense", "complicated",
            "difficult", "hard to", "still don't", "not working",
            "useless", "terrible", "hate", "ridiculous", "stupid"
        };

        private static readonly string[] CuriousKeywords =
        {
            "curious", "interesting", "wonder", "how does", "why does",
            "tell me more", "explain", "what exactly", "how exactly",
            "want to know", "can you explain", "more details", "elaborate"
        };

        private static readonly string[] GratefulKeywords =
        {
            "thank", "thanks", "appreciate", "helpful", "that helped",
            "great help", "you're great", "good bot", "nice", "well done"
        };

        private static readonly string[] PositiveKeywords =
        {
            "awesome", "amazing", "love it", "great", "excellent",
            "perfect", "fantastic", "brilliant", "cool", "wow",
            "learned", "got it", "i see", "makes sense", "understand now"
        };

        // ---------------------------------------------------------------
        // DETECT
        // Returns the detected sentiment for a given input string.
        // ---------------------------------------------------------------
        public static Sentiment Detect(string input)
        {
            string lower = input.ToLower();

            if (ContainsAny(lower, WorriedKeywords))    return Sentiment.Worried;
            if (ContainsAny(lower, FrustratedKeywords)) return Sentiment.Frustrated;
            if (ContainsAny(lower, GratefulKeywords))   return Sentiment.Grateful;
            if (ContainsAny(lower, PositiveKeywords))   return Sentiment.Positive;
            if (ContainsAny(lower, CuriousKeywords))    return Sentiment.Curious;

            return Sentiment.Neutral;
        }

        // ---------------------------------------------------------------
        // GET EMPATHETIC PREFIX
        // Returns a short empathetic sentence to prepend to the response.
        // Makes the bot feel more human and responsive to mood.
        // ---------------------------------------------------------------
        public static string GetEmpatheticPrefix(Sentiment sentiment)
        {
            return sentiment switch
            {
                Sentiment.Worried =>
                    "I completely understand your concern — it's smart to take these threats seriously. ",

                Sentiment.Frustrated =>
                    "No worries, let me try to make this clearer for you. ",

                Sentiment.Curious =>
                    "Great question! I love the curiosity — here's what you need to know. ",

                Sentiment.Grateful =>
                    "You're very welcome! Happy to help. ",

                Sentiment.Positive =>
                    "Glad you're finding this useful! ",

                _ => "" // Neutral — no prefix needed
            };
        }

        // ---------------------------------------------------------------
        // GET SENTIMENT LABEL  (shown in the UI status bar)
        // ---------------------------------------------------------------
        public static string GetLabel(Sentiment sentiment)
        {
            return sentiment switch
            {
                Sentiment.Worried    => "😟 Worried",
                Sentiment.Frustrated => "😤 Frustrated",
                Sentiment.Curious    => "🤔 Curious",
                Sentiment.Grateful   => "😊 Grateful",
                Sentiment.Positive   => "😄 Positive",
                _                    => ""
            };
        }

        // ---------------------------------------------------------------
        // PRIVATE HELPER
        // ---------------------------------------------------------------
        private static bool ContainsAny(string input, string[] keywords)
        {
            foreach (string kw in keywords)
                if (input.Contains(kw)) return true;
            return false;
        }
    }
}
