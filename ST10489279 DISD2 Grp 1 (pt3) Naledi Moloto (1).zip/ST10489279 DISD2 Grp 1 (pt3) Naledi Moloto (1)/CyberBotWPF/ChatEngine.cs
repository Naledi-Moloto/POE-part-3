// =======================================================================
// ChatEngine.cs  -  Bot/
// -----------------------------------------------------------------------
// The main brain of the chatbot. Receives cleaned user input and
// returns the appropriate response string.
//
// IMPORTANT - ORDER OF CHECKS IN RouteInput():
//   Topics are checked BEFORE greetings. 
// =======================================================================

namespace CyberBotWPF.Bot
{
    public class ChatEngine
    {
        private readonly MemoryStore         _memory  = new();
        private readonly ConversationContext _context = new();

        public MemoryStore Memory         => _memory;
        public ConversationContext Context => _context;

        private int _lastIndex = 0;

        // ---------------------------------------------------------------
        // PROCESS INPUT  (called by MainWindow on every message)
        // ---------------------------------------------------------------
        public string ProcessInput(string rawInput, out Sentiment detectedSentiment)
        {
            string input = rawInput.Trim().ToLower();

            // Step 1: Detect sentiment
            detectedSentiment = SentimentDetector.Detect(input);
            string sentimentPrefix = SentimentDetector.GetEmpatheticPrefix(detectedSentiment);

            // Step 2: Try to store personal info (name, job, concern)
            bool storedSomething = _memory.TryExtractAndStore(input);
            if (storedSomething && _memory.UserName != null &&
                input.Contains(_memory.UserName.ToLower()))
            {
                return $"Nice to meet you, {_memory.UserName}! I'll remember that. " +
                       "Feel free to ask me anything about cybersecurity!";
            }

            // Step 3: Special commands
            if (ContainsAny(input, new[] { "quit", "exit", "bye", "goodbye" }))
                return GetFarewell();

            if (ContainsAny(input, new[] { "help", "menu", "topics", "what can you do" }))
                return ResponseLibrary.HelpText;

            if (ContainsAny(input, new[] { "what do you remember", "what do you know about me",
                                           "my details", "remember about me" }))
                return "Here's what I remember about you: " + _memory.SummariseMemory();

            // Step 4: Follow-up check
            if (_context.IsFollowUp(input) && _context.CurrentTopic != Topic.None)
            {
                _context.BumpFollowUp();
                string followUp = GetFollowUpResponse(_context.CurrentTopic);
                return sentimentPrefix + ResponseLibrary.GetRandomTransition()
                       + "\n\n" + followUp;
            }

            // Step 5: Route to topic or greeting
            string response = RouteInput(input, rawInput);
            return sentimentPrefix + response;
        }

        // ---------------------------------------------------------------
        // ROUTE INPUT
        // Topics are checked FIRST, then greetings, then default.
        // ---------------------------------------------------------------
        private string RouteInput(string input, string rawInput)
        {
            // ============================================================
            // TOPICS FIRST
            // ============================================================

            // -- Phishing --
            if (ContainsAny(input, new[] { "what is phishing", "define phishing",
                "phishing meaning", "phishing definition", "explain phishing" }))
            {
                _context.SetTopic(Topic.Phishing, SubTopic.Definition);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.PhishingDefinitions, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "phishing red flag", "phishing sign",
                "spot phishing", "phishing warning", "identify phishing" }))
            {
                _context.SetTopic(Topic.Phishing, SubTopic.RedFlags);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.PhishingRedFlags, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "phishing tip", "avoid phishing",
                "prevent phishing", "phishing advice", "phishing protection" }))
            {
                _context.SetTopic(Topic.Phishing, SubTopic.Tips);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.PhishingTips, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "phishing example", "phishing scenario",
                "show me phishing", "fake email example", "sample phishing" }))
            {
                _context.SetTopic(Topic.Phishing, SubTopic.Scenario);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.PhishingScenarios, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "phishing", "phish", "scam email", "fake email" }))
            {
                _context.SetTopic(Topic.Phishing);
                return BroadTopicResponse("phishing",
                    "what is phishing · phishing red flags · phishing tip · phishing example");
            }

            // -- Passwords --
            if (ContainsAny(input, new[] { "what is a strong password", "define password","password definition",
                "strong password meaning", "what makes a good password" }))
            {
                _context.SetTopic(Topic.Password, SubTopic.Definition);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.PasswordDefinitions, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "password tip", "password advice",
                "how to make a password", "create strong password", "password best practice" }))
            {
                _context.SetTopic(Topic.Password, SubTopic.Tips);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.PasswordTips, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "bad password", "weak password",
                "passwords to avoid", "worst password", "common password" }))
            {
                _context.SetTopic(Topic.Password, SubTopic.BadPasswords);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.PasswordsToAvoid, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "passphrase", "pass phrase",
                "what is a passphrase", "passphrase example" }))
            {
                _context.SetTopic(Topic.Password, SubTopic.Passphrase);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.PassphraseInfo, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "password", "passwords", "credentials", "login" }))
            {
                _context.SetTopic(Topic.Password);
                return BroadTopicResponse("passwords",
                    "what is a strong password · password tips · bad passwords · what is a passphrase");
            }

            // -- Suspicious Links --
            if (ContainsAny(input, new[] { "what is a suspicious link", "define suspicious link","suspicious link definition",
                "what is a malicious link", "dangerous link definition" }))
            {
                _context.SetTopic(Topic.Links, SubTopic.Definition);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.LinksDefinitions, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "link red flag", "url warning", "suspicious url",
                "how to spot a bad link", "bad url", "link warning" }))
            {
                _context.SetTopic(Topic.Links, SubTopic.RedFlags);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.LinksRedFlags, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "link tip", "link safety", "how to check a link",
                "avoid bad link", "link protection", "url tip" }))
            {
                _context.SetTopic(Topic.Links, SubTopic.Tips);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.LinksTips, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "link exercise", "spot the fake", "fake url",
                "url example", "link example", "fake link" }))
            {
                _context.SetTopic(Topic.Links, SubTopic.Exercise);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.LinksExercises, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "link", "url", "suspicious link", "website", "web" }))
            {
                _context.SetTopic(Topic.Links);
                return BroadTopicResponse("suspicious links",
                    "what is a suspicious link · link red flags · link tips · link exercise");
            }

            // -- Malware --
            if (ContainsAny(input, new[] { "what is malware", "define malware",
                "malware meaning", "malware definition", "explain malware" }))
            {
                _context.SetTopic(Topic.Malware, SubTopic.Definition);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.MalwareDefinitions, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "types of malware", "malware types", "list malware",
                "kinds of malware", "malware examples", "different malware" }))
            {
                _context.SetTopic(Topic.Malware, SubTopic.Types);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.MalwareTypes, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "malware tip", "prevent malware", "avoid malware",
                "malware protection", "virus protection", "malware prevention" }))
            {
                _context.SetTopic(Topic.Malware, SubTopic.Tips);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.MalwareTips, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "backup rule", "3-2-1", "321 rule",
                "backup tips", "how to back up", "data backup" }))
            {
                _context.SetTopic(Topic.Malware, SubTopic.BackupRule);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.BackupRuleInfo, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "malware", "virus", "ransomware",
                "trojan", "spyware", "worm", "infected" }))
            {
                _context.SetTopic(Topic.Malware);
                return BroadTopicResponse("malware",
                    "what is malware · types of malware · malware tips · backup rule");
            }

            // -- Social Engineering --
            if (ContainsAny(input, new[] { "what is social engineering", "define social engineering","social engineering definition",
                "social engineering meaning", "explain social engineering" }))
            {
                _context.SetTopic(Topic.SocialEngineering, SubTopic.Definition);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.SocialDefinitions, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "social engineering tactic", "types of social engineering",
                "social engineering example", "pretexting", "baiting", "vishing", "tailgating" }))
            {
                _context.SetTopic(Topic.SocialEngineering, SubTopic.Tactics);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.SocialTactics, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "social engineering tip", "avoid social engineering",
                "prevent social engineering", "defend against social" }))
            {
                _context.SetTopic(Topic.SocialEngineering, SubTopic.Tips);
                return GetPersonalised(ResponseLibrary.GetRandom(
                    ResponseLibrary.SocialTips, ref _lastIndex));
            }
            if (ContainsAny(input, new[] { "social engineering", "social", "manipulation",
                "psychological attack", "human hacking" }))
            {
                _context.SetTopic(Topic.SocialEngineering);
                return BroadTopicResponse("social engineering",
                    "what is social engineering · social engineering tactics · social engineering tips");
            }

            // ============================================================
            // GREETINGS AFTER TOPICS  — safe now that topics are handled
            // ============================================================

            if (ContainsAny(input, new[] { "hello", "hi", "hey", "howdy", "greetings",
                "good morning", "good afternoon", "good evening", "sup", "yo", "hiya" }))
            {
                string greeting = ResponseLibrary.GetRandom(
                    ResponseLibrary.Greetings, ref _lastIndex);
                if (_memory.UserName != null)
                    greeting = $"Hello again, {_memory.UserName}! " + greeting;
                return greeting;
            }

            if (ContainsAny(input, new[] { "how are you", "how r you", "you good",
                "you okay", "how do you do", "hows it going" }))
                return ResponseLibrary.GetRandom(ResponseLibrary.HowAreYou, ref _lastIndex);

            if (ContainsAny(input, new[] { "your purpose", "what do you do", "what are you",
                "who are you", "tell me about yourself", "what are you for" }))
                return ResponseLibrary.GetRandom(ResponseLibrary.Purpose, ref _lastIndex);

            // -- Gratitude --
            if (ContainsAny(input, new[] { "thank", "thanks", "appreciate", "helpful" }))
            {
                string name = _memory.UserName != null ? $", {_memory.UserName}" : "";
                return $"You're very welcome{name}! Stay safe out there. " +
                       "Feel free to ask me anything else about cybersecurity!";
            }

            // -- Default --
            return GetDefaultResponse(rawInput);
        }

        // ---------------------------------------------------------------
        // GET FOLLOW-UP RESPONSE
        // ---------------------------------------------------------------
        private string GetFollowUpResponse(Topic topic)
        {
            return topic switch
            {
                Topic.Phishing => _context.LastSubTopic switch
                {
                    SubTopic.Tips     => ResponseLibrary.GetRandom(ResponseLibrary.PhishingTips,     ref _lastIndex),
                    SubTopic.RedFlags => ResponseLibrary.GetRandom(ResponseLibrary.PhishingRedFlags,  ref _lastIndex),
                    SubTopic.Scenario => ResponseLibrary.GetRandom(ResponseLibrary.PhishingScenarios, ref _lastIndex),
                    _                 => ResponseLibrary.GetRandom(ResponseLibrary.PhishingTips,      ref _lastIndex),
                },
                Topic.Password => _context.LastSubTopic switch
                {
                    SubTopic.Tips         => ResponseLibrary.GetRandom(ResponseLibrary.PasswordTips,     ref _lastIndex),
                    SubTopic.BadPasswords => ResponseLibrary.GetRandom(ResponseLibrary.PasswordsToAvoid, ref _lastIndex),
                    SubTopic.Passphrase   => ResponseLibrary.GetRandom(ResponseLibrary.PassphraseInfo,   ref _lastIndex),
                    _                     => ResponseLibrary.GetRandom(ResponseLibrary.PasswordTips,     ref _lastIndex),
                },
                Topic.Links => _context.LastSubTopic switch
                {
                    SubTopic.Tips     => ResponseLibrary.GetRandom(ResponseLibrary.LinksTips,      ref _lastIndex),
                    SubTopic.RedFlags => ResponseLibrary.GetRandom(ResponseLibrary.LinksRedFlags,   ref _lastIndex),
                    SubTopic.Exercise => ResponseLibrary.GetRandom(ResponseLibrary.LinksExercises,  ref _lastIndex),
                    _                 => ResponseLibrary.GetRandom(ResponseLibrary.LinksTips,       ref _lastIndex),
                },
                Topic.Malware => _context.LastSubTopic switch
                {
                    SubTopic.Tips       => ResponseLibrary.GetRandom(ResponseLibrary.MalwareTips,    ref _lastIndex),
                    SubTopic.Types      => ResponseLibrary.GetRandom(ResponseLibrary.MalwareTypes,   ref _lastIndex),
                    SubTopic.BackupRule => ResponseLibrary.GetRandom(ResponseLibrary.BackupRuleInfo, ref _lastIndex),
                    _                   => ResponseLibrary.GetRandom(ResponseLibrary.MalwareTips,    ref _lastIndex),
                },
                Topic.SocialEngineering => _context.LastSubTopic switch
                {
                    SubTopic.Tactics => ResponseLibrary.GetRandom(ResponseLibrary.SocialTactics, ref _lastIndex),
                    SubTopic.Tips    => ResponseLibrary.GetRandom(ResponseLibrary.SocialTips,    ref _lastIndex),
                    _                => ResponseLibrary.GetRandom(ResponseLibrary.SocialTips,    ref _lastIndex),
                },
                _ => "I'm not sure what to add — try asking about a specific topic!"
            };
        }

        // ---------------------------------------------------------------
        // HELPERS
        // ---------------------------------------------------------------
        private string BroadTopicResponse(string topicName, string subTopics)
        {
            string name = _memory.UserName != null ? $", {_memory.UserName}" : "";
            return $"I can help with several things about {topicName}{name}. " +
                   $"What specifically would you like to know?\n\n" +
                   $"You can ask me:\n  • {subTopics.Replace(" · ", "\n  • ")}\n\n";
        }

        private string GetPersonalised(string response)
        {
            if (_memory.UserName != null)
                return $"{_memory.PersonalPrefix()}{response}";
            return response;
        }

        private string GetDefaultResponse(string originalInput)
        {
            string name = _memory.UserName != null ? $", {_memory.UserName}" : "";
            return $"I didn't quite understand \"{originalInput}\"{name}. " +
                   "Could you rephrase that?\n\n" +
                   "Try typing: phishing · password · links · malware · social\n" +
                   "Or type 'help' to see the full menu.";
        }

        private string GetFarewell()
        {
            string name = _memory.UserName != null ? $", {_memory.UserName}" : "";
            return $"Goodbye{name}! Thanks for using Goose. " +
                   "Stay safe and think before you click! 🛡️";
        }

        private static bool ContainsAny(string input, string[] keywords)
        {
            foreach (string kw in keywords)
                if (input.Contains(kw)) return true;
            return false;
        }
    }
}
