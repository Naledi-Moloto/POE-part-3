using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CybersecurityChatbot
{
    public enum Intent
    {
        Unknown,
        Greeting,
        Farewell,
        Help,
        // "More" / continuation
        More,
        // Task intents
        AddTask,
        ViewTasks,
        DeleteTask,
        CompleteTask,
        // Quiz
        StartQuiz,
        // Log
        ViewLog,
        // Cybersecurity topics
        Phishing,
        Password,
        Malware,
        SocialEngineering,
        SuspiciousLink,
        Privacy,
        TwoFactorAuth,
        PublicWifi,
        Ransomware,
        // Sentiment fallbacks
        PositiveSentiment,
        NegativeSentiment
    }

    public class NlpResult
    {
        public Intent Intent     { get; set; }
        public string Keyword    { get; set; }
        public double Confidence { get; set; }
        public string Sentiment  { get; set; }
    }

    public static class NlpEngine
    {
        // ------------------------------------------------------------------
        // Intent map.
        // IMPORTANT: phrases are matched with word-boundary regex so that
        // "hi" inside "phishing" does NOT trigger Greeting.
        // Longer / more-specific phrases are listed FIRST so they win.
        // ------------------------------------------------------------------
        private static readonly Dictionary<Intent, List<string>> _intentMap =
            new Dictionary<Intent, List<string>>
        {
            // ── Greetings – short words so must be whole-word matched ──────
            { Intent.Greeting, new List<string> {
                "good morning","good afternoon","good evening",
                "howdy","greetings","what's up","whats up",
                "hello","hey","hi" } },          // "hi"/"hey" checked LAST, word-boundary only

            { Intent.Farewell, new List<string> {
                "goodbye","see you later","take care","see ya",
                "bye","exit","quit","cya","later" } },

            { Intent.Help, new List<string> {
                "what can you do","show me commands","show commands",
                "how do i use","how do i","options","commands","menu",
                "guide","support","assist","help" } },

            // ── Continuation ──────────────────────────────────────────────
            { Intent.More, new List<string> {
                "tell me more","give me more","show me more","more info",
                "another example","give another","more please","another tip",
                "more tips","another","more" } },

            // ── Tasks ─────────────────────────────────────────────────────
            { Intent.AddTask, new List<string> {
                "add a task","create a task","add security task","make a task",
                "i want to add","i need to add","log task","record task",
                "set a reminder","add a reminder","create a reminder",
                "set reminder","add reminder","create reminder",
                "schedule task","remind me to","remind me",
                "add task","create task","new task" } },

            { Intent.ViewTasks, new List<string> {
                "show my tasks","display tasks","view my tasks","see my tasks",
                "list my tasks","all my tasks","pending tasks","show reminders",
                "view reminders","check tasks","task list","open tasks",
                "view tasks","show tasks","list tasks","my tasks","see tasks" } },

            { Intent.DeleteTask, new List<string> {
                "delete a task","remove a task","cancel a task","erase a task",
                "get rid of task","drop task","delete reminder","remove reminder",
                "delete task","remove task","cancel task","erase task" } },

            { Intent.CompleteTask, new List<string> {
                "mark as complete","mark as done","task is done","i finished",
                "mark finished","complete task","mark complete","finish task",
                "done task","task done","completed" } },

            // ── Quiz ──────────────────────────────────────────────────────
            { Intent.StartQuiz, new List<string> {
                "start the quiz","start a quiz","take the quiz","play the quiz",
                "test my knowledge","challenge me","knowledge test",
                "cybersecurity quiz","mini game","minigame","trivia",
                "start quiz","play quiz","take quiz","play game","quiz" } },

            // ── Activity log ──────────────────────────────────────────────
            { Intent.ViewLog, new List<string> {
                "show activity log","view activity log","show the log",
                "recent actions","bot history","action log","show history",
                "activity history","recent activity","chatbot log",
                "activity log","view log","history","show log","log" } },

            // ── Cybersecurity topics ───────────────────────────────────────
            // Phishing MUST come before any short-word intents
            { Intent.Phishing, new List<string> {
                "spear phishing","email scam","fake email","phishing email",
                "email attack","fraudulent email","suspicious email",
                "vishing","smishing","phishing","phish" } },

            { Intent.Password, new List<string> {
                "password manager","password safety","strong password",
                "weak password","change password","password tips","secure password",
                "login details","credentials","passphrase","password" } },

            { Intent.Malware, new List<string> {
                "malicious software","malware attack","computer virus",
                "trojan horse","spyware","adware","rootkit","keylogger",
                "malware","virus","trojan","worm","antivirus","infected" } },

            { Intent.SocialEngineering, new List<string> {
                "social engineering","human hacking","fake identity",
                "pretend to be","impersonation","manipulation","pretexting",
                "baiting","tailgating" } },

            { Intent.SuspiciousLink, new List<string> {
                "suspicious link","suspicious url","malicious link","bad link",
                "unsafe link","do not click","don't click","strange link",
                "unknown link","weird link","dodgy link" } },

            { Intent.Privacy, new List<string> {
                "privacy settings","personal information","personal data",
                "data protection","oversharing","private data","gdpr","privacy" } },

            { Intent.TwoFactorAuth, new List<string> {
                "two factor authentication","two-factor authentication",
                "multi factor","multi-factor","authenticator app",
                "one time password","two factor","two-factor",
                "2fa","mfa","otp" } },

            { Intent.PublicWifi, new List<string> {
                "public wi-fi","public wifi","open wifi","coffee shop wifi",
                "unsecured network","free wifi","hotspot","vpn" } },

            { Intent.Ransomware, new List<string> {
                "crypto locker","encrypted files","pay ransom","locked files",
                "file encryption attack","ransomware","ransom" } }
        };

        // Positive / negative sentiment words
        private static readonly List<string> _positive = new List<string>
        {
            "good","great","awesome","excellent","thanks","thank","appreciate",
            "helpful","nice","love","perfect","happy","wonderful","fantastic",
            "brilliant","amazing","cool","superb","pleased","well done"
        };

        private static readonly List<string> _negative = new List<string>
        {
            "bad","terrible","awful","hate","worst","useless","stupid",
            "confused","scared","worried","anxious","angry","frustrated",
            "annoyed","upset","lost","hopeless","broken","difficult","problem","error"
        };

        // ------------------------------------------------------------------
        public static NlpResult Analyse(string userInput)
        {
            if (string.IsNullOrWhiteSpace(userInput))
                return new NlpResult { Intent = Intent.Unknown, Confidence = 0, Sentiment = "neutral" };

            string lower = userInput.ToLowerInvariant().Trim();
            string clean = StripPunctuation(lower);

            var (intent, keyword, confidence) = DetectIntent(clean, lower);
            string sentiment = DetectSentiment(clean);

            // Only fall back to sentiment if nothing else matched
            if (intent == Intent.Unknown)
            {
                if (sentiment == "positive") intent = Intent.PositiveSentiment;
                if (sentiment == "negative") intent = Intent.NegativeSentiment;
            }

            return new NlpResult
            {
                Intent     = intent,
                Keyword    = keyword,
                Confidence = confidence,
                Sentiment  = sentiment
            };
        }

        // ------------------------------------------------------------------
        private static (Intent, string, double) DetectIntent(string clean, string original)
        {
            foreach (var kvp in _intentMap)
            {
                foreach (string phrase in kvp.Value)
                {
                    // Use word-boundary regex for single short words to avoid
                    // substring false-positives (e.g. "hi" inside "phishing")
                    bool matched;
                    if (!phrase.Contains(' ') && phrase.Length <= 5)
                        matched = Regex.IsMatch(clean, @"\b" + Regex.Escape(phrase) + @"\b");
                    else
                        matched = clean.Contains(phrase);

                    if (matched)
                    {
                        int wordCount = phrase.Split(' ').Length;
                        double conf   = Math.Min(0.5 + wordCount * 0.15, 1.0);
                        return (kvp.Key, phrase, conf);
                    }
                }
            }
            return (Intent.Unknown, string.Empty, 0.0);
        }

        // ------------------------------------------------------------------
        private static string DetectSentiment(string clean)
        {
            int pos = _positive.Count(w => Regex.IsMatch(clean, @"\b" + Regex.Escape(w) + @"\b"));
            int neg = _negative.Count(w => Regex.IsMatch(clean, @"\b" + Regex.Escape(w) + @"\b"));
            if (pos > neg) return "positive";
            if (neg > pos) return "negative";
            return "neutral";
        }

        private static string StripPunctuation(string s)
            => new string(s.Where(c => !char.IsPunctuation(c) || c == '\'').ToArray());

        // ------------------------------------------------------------------
        // Heuristic: extract a task title from raw user text
        // ------------------------------------------------------------------
        public static string ExtractTaskTitle(string userInput)
        {
            string lower = userInput.ToLowerInvariant();
            string[] stripPhrases =
            {
                "add a task called","add task called","create task called",
                "add a task","create a task","new task","add task","create task",
                "set a reminder for","set reminder for","add a reminder for",
                "remind me to","remind me","schedule task","log task"
            };

            foreach (var phrase in stripPhrases)
            {
                int idx = lower.IndexOf(phrase, StringComparison.OrdinalIgnoreCase);
                if (idx >= 0)
                {
                    string remainder = userInput.Substring(idx + phrase.Length).Trim(' ', ':');
                    if (remainder.Length > 2)
                        return char.ToUpper(remainder[0]) + remainder.Substring(1);
                }
            }
            return char.ToUpper(userInput[0]) + userInput.Substring(1);
        }
    }
}
